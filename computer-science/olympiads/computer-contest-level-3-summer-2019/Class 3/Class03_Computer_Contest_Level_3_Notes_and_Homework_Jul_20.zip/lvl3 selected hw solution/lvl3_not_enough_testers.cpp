#include <bits/stdc++.h>
using namespace std;
int T, maxv=100000, cnt[100001]; vector<int> lst[100001];
int main(){
    scanf("%d", &T);
    for(int i=1; i<=maxv; i++){
        for(int j=i; j<=maxv; j+=i)
            cnt[j]++;
        lst[cnt[i]].push_back(i);
    }
    for(int i=1, k, a, b; i<=T; i++){
        scanf("%d %d %d", &k, &a, &b);
        printf("%d\n", upper_bound(lst[k].begin(), lst[k].end(), b) -
               lower_bound(lst[k].begin(), lst[k].end(), a));
    }
}