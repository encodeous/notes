import java.util.*;
import java.io.*;
public class Test {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static StringTokenizer st;
	public static void main(String[] args) throws IOException {
		int maxV = 100001, fact[] = new int[maxV];
		List<Integer> list[] = new ArrayList[maxV];
		for(int i=0; i<maxV; i++) list[i] = new ArrayList();
		for(int i=1; i<maxV; i++) {
			for(int j=i; j<maxV; j+=i) {
				fact[j]++;
			}
			list[ fact[i] ].add(i);
		}
		int Q = readInt();
		for(int i=1; i<=Q; i++) {
			int k = readInt(), a = readInt(), b = readInt();
			int pa = Collections.binarySearch(list[k], a), pb = Collections.binarySearch(list[k], b);
			if(pa < 0) pa = -pa - 1;  //find the first position > a if a doesn't exist
			if(pb < 0) pb = -pb - 2;  //find the last position < b if b doesn't exist
			System.out.println(pb - pa + 1);
		}
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}