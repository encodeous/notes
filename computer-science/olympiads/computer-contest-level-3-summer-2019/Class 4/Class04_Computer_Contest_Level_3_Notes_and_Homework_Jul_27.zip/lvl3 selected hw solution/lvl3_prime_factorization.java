import java.util.*;
import java.io.*;
public class Test {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static StringTokenizer st;
	static ArrayList<Integer> prime = new ArrayList<Integer>();
	public static void main(String[] args) throws IOException{
		sieve();
		int n = readInt();
		for(int i=1; i<=n; i++){
			int x = readInt(), y = (int)Math.sqrt(x);
			for(int f: prime){
				if(f > y) break;
				while(x % f == 0) { System.out.print(f+" "); x/=f; }
			}
			if(x != 1) System.out.println(x);
			else System.out.println();
		}
	}
	public static void sieve(){
		int up = (int)Math.sqrt(1e7);
		boolean filter [] = new boolean[up+1];
		for(int i=2; i<=up; i++){
			if(!filter[i]){
				prime.add(i);
				for(int j=i*i; j<=up; j+=i) filter[j]=true;
			}
		}
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}