import java.util.*;
public class dmoj_secret_santa {
	static int tot=0;
	static int ans=Integer.MAX_VALUE;
	public static void main(String [] args){
		Scanner in = new Scanner(System.in);
		ArrayList<Gift> g = new ArrayList<Gift>();
		int N = in.nextInt();
		for(int i=0; i<N; i++){
			int f=in.nextInt(), w=in.nextInt();
			tot += w; g.add(new Gift(f, w));
		}
		recurse(new Gift(101, tot), 0, g);
		System.out.println(ans);
	}
	static void recurse(Gift cur, int sol, ArrayList<Gift>lst){
		if(lst.isEmpty()) {
			ans=Math.min(ans,  sol);
			return;
		}
		for(int i=0; i<lst.size(); i++){
			int cf = lst.get(i).floor, cw=lst.get(i).weight;
			int load= (Math.abs(cur.floor-cf)+1)*cur.weight;
			ArrayList<Gift> tmp = new ArrayList<Gift>();
			for(int j=0; j<lst.size(); j++)
				if(j!=i) tmp.add(lst.get(j));
			recurse(new Gift(cf, cur.weight-cw), sol+load, tmp);
		}
	}
	static class Gift{
		int floor, weight;
		Gift(int f, int w){ floor=f; weight=w;}
	}
}