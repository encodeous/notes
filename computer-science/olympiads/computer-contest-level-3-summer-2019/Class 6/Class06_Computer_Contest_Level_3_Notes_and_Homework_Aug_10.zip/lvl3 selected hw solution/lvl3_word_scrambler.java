import java.util.*;
import java.io.*;
public class Test {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static StringTokenizer st;
	public static void main(String[] args) throws IOException {
		char ch[] = readLine().toCharArray();
		Arrays.sort(ch);
		getPermutation(new String(ch), "");
	}
	static void getPermutation(String a, String perm) {
		if(a.isEmpty()) {
			System.out.println(perm);
			return;
		}
		for(int i=0; i<a.length(); i++)
			getPermutation( a.substring(0, i)+a.substring(i+1), perm + a.charAt(i) );
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}