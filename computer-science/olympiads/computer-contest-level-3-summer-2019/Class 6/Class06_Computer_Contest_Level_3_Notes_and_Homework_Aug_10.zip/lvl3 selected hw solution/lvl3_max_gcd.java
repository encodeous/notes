import java.util.*;
import java.io.*;
public class Test {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static StringTokenizer st;
	public static void main(String[] args) throws IOException {
		int n = readInt();
		int[] a = new int[n];
		for (int i = 0; i < n; i++) {
			a[i] = readInt();
		}
		int[] pre = new int[n];
		int[] suf = new int[n];
		pre[0] = a[0];
		suf[n - 1] = a[n - 1];
		for (int i = 1; i < n; i++) {
			pre[i] = gcd(a[i], pre[i - 1]);
		}
		for (int i = n - 2; i >= 0; i--) {
			suf[i] = gcd(a[i], suf[i + 1]);
		}
		int maxGcd = 1;
		for (int i = 0; i < n; i++) {
			if (i == 0) {
				maxGcd = Math.max(suf[i + 1], maxGcd);
			} else if (i == n - 1) {
				maxGcd = Math.max(pre[i - 1], maxGcd);
			} else 
			maxGcd = Math.max(gcd(suf[i + 1], pre[i - 1]), maxGcd);
		}
		System.out.println(maxGcd);
	}
	public static int gcd(int a, int b) {
		return (b == 0 ? a : gcd(b, a % b));
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}