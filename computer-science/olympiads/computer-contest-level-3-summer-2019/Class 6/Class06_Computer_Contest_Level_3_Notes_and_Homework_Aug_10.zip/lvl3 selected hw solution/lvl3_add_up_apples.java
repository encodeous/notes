import java.util.*;
public class aplusb{
	static int cnt = 0, n = 0;
	public static void main(String [] args){
		Scanner in = new Scanner(System.in);
		n = in.nextInt();
		for(int i=1; i<=n/2; i++)
			fun(i, i, String.valueOf(i));
		System.out.println("total="+cnt);
	}
	static void fun(int start, int sum, String ans){
		if(sum == n){
			System.out.println(n + "=" + ans); cnt++; 
			return;
		}
		for(int i=start; i+sum <= n; i++)
			fun(i, i + sum, ans + "+" + i);
	}
}