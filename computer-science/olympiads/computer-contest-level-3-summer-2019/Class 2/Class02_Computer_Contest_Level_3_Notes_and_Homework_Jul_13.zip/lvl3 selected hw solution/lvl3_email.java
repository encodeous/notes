import java.util.*;
public class test2 {
  public static void main(String[] args) {
	  Scanner in = new Scanner(System.in);
	  for(int k=1; k<=10; k++) {
		  int n = in.nextInt(); HashSet<String> set = new HashSet();
		  for(int i=1; i<=n; i++) {
			  String [] s = in.next().toLowerCase().split("@");
			  s[0] = s[0].replaceAll("\\.", "");
			  int pos = s[0].indexOf("+");
			  if(pos != -1) s[0] = s[0].substring(0, pos);
			  set.add(s[0]+"@"+s[1]);
		  }
		  System.out.println(set.size());
	  }
  }
}