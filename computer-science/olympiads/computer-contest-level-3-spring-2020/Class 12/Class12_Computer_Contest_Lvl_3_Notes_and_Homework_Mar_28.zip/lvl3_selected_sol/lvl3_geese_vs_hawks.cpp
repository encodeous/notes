#include <bits/stdc++.h>
using namespace std;
int N, dp[1002][1002], a[1002], b[1002]; char s[1003], t[1003];
int main(){
    scanf("%d %s", &N, s+1);
    for(int i=1; i<=N; i++) scanf("%d", &a[i]);
    scanf(" %s", t+1);
    for(int i=1; i<=N; i++) scanf("%d", &b[i]);
    for(int i=1; i<=N; i++){
        for(int j=1; j<=N; j++){
            dp[i][j] = max(dp[i-1][j], dp[i][j-1]);
            if(s[i] != t[j] && (s[i]=='W' && a[i] > b[j] || s[i]=='L' && a[i] < b[j]))
                dp[i][j] = max(dp[i][j], dp[i-1][j-1] + a[i] + b[j]);
        }
    }
    printf("%d\n", dp[N][N]);
}