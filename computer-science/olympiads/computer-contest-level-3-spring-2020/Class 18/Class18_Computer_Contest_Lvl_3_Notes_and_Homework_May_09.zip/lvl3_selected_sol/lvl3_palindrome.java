import java.util.*;
import java.io.*;
import java.math.*;
public class homework {
    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    static StringTokenizer st;
    public static void main(String[] args) throws IOException{
    	int n = readInt(), dp[][] = new int[2][n]; 
    	char s[] = readLine().toCharArray();
    	int pre = 0, cur = 1;
    	for(int i=n-2; i>=0; i--) {
    		for(int j=i+1; j<n; j++) {
    			if(s[i] == s[j]) dp[cur][j] = dp[pre][j-1];
    			else dp[cur][j] = 1 + Math.min(dp[cur][j-1], dp[pre][j]);
    		}
    		int tmp = pre; pre = cur; cur = tmp;
    	}
    	System.out.println(dp[pre][n-1]);
    }
    static String next () throws IOException {
        while (st == null || !st.hasMoreTokens())
            st = new StringTokenizer(br.readLine().trim());
        return st.nextToken();
    }
    static long readLong () throws IOException {
        return Long.parseLong(next());
    }
    static int readInt () throws IOException {
        return Integer.parseInt(next());
    }
    static double readDouble () throws IOException {
        return Double.parseDouble(next());
    }
    static char readCharacter () throws IOException {
        return next().charAt(0);
    }
    static String readLine () throws IOException {
        return br.readLine().trim();
    }
}