#include <bits/stdc++.h>
using namespace std;
#define x first
#define y second
#define LE 0
#define RE 1
typedef pair<int, int> pi;
typedef long long ll;
int n; pi a[2002];  ll  psa[2002], ans, dp[2002][2002][2];
int main(){
    scanf("%d", &n);
    for(int i=1; i<=n; i++) scanf("%d %d", &a[i].x, &a[i].y);
    sort(a+1, a+n+1);
    for(int i=1; i<=n; i++){
        psa[i] = psa[i-1]+a[i].y;
        if(a[i].x==0) dp[i][i][LE] = dp[i][i][RE] = a[i].y;
    }
    for(int len=1; len<n; len++){
        for(int l=1; l+len<=n; l++){
            int r = l+len;
            if(dp[l+1][r][LE] >= a[l+1].x - a[l].x)
                dp[l][r][LE]=max(dp[l][r][LE], dp[l+1][r][LE]+a[l].y-(a[l+1].x-a[l].x));
            if(dp[l+1][r][RE] >= a[r].x - a[l].x)
                dp[l][r][LE]=max(dp[l][r][LE], dp[l+1][r][RE]+a[l].y-(a[r].x-a[l].x));
            if(dp[l][r-1][RE] >= a[r].x - a[r-1].x)
                dp[l][r][RE]=max(dp[l][r][RE], dp[l][r-1][RE]+a[r].y-(a[r].x-a[r-1].x));
            if(dp[l][r-1][LE] >= a[r].x - a[l].x)
                dp[l][r][RE]=max(dp[l][r][RE], dp[l][r-1][LE]+a[r].y-(a[r].x-a[l].x));
        }
    }
    for(int l=1; l<=n; l++)
        for(int r=l; r<=n; r++)
            if(dp[l][r][LE]>0 || dp[l][r][RE]>0) ans = max(ans, psa[r]-psa[l-1]);
    printf("%lld\n", ans);
}