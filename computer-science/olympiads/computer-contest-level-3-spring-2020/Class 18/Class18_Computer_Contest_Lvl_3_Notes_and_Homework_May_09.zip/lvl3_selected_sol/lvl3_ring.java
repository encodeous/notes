import java.util.*;
import java.io.*;
import java.math.*;
public class homework {
    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    static StringTokenizer st;
    public static void main(String[] args) throws IOException{
    	int mod = (int)1e9+7;
    	for(int T = readInt(); T > 0; T--) {
    		int n = readInt(); Map<String, pair> func = new HashMap();
    		Stack<String> st = new Stack();
    		func.put("main", new pair(1, 0)); st.push("main");
    		for(int i=1; i<=n; i++) {
    			String s = next();
    			if(s.equals("END")) st.pop();
    			else if(s.equals("FUN")) {
    				String name = next();  func.put(name, new pair(1, 0)); st.push(name);
    			}else if(s.equals("CALL")) {
    				String name = next();  
    				pair t1 = func.get(st.peek()), t2 = func.get(name);
    				func.put(st.peek(), new pair(t1.m * t2.m % mod, (t1.b * t2.m + t2.b)%mod));
    			} else if(s.equals("ADD")) {
    				int x = readInt();  pair t1 = func.get(st.peek());
    				func.put(st.peek(), new pair(t1.m, (t1.b+x)%mod));
    			} else if(s.equals("SUB")) {
    				int x = readInt();  pair t1 = func.get(st.peek());
    				func.put(st.peek(), new pair(t1.m, (t1.b-x+mod)%mod));
    			} else if (s.equals("MULT")) {
    				int x = readInt();  pair t1 = func.get(st.peek());
    				func.put(st.peek(), new pair(t1.m*x %mod, t1.b*x%mod));
    			}
    		}
    		System.out.println(func.get("main").b);
    	}
    }
    static class pair {
    	long m, b; // m is slope and  b is intercept
    	pair(long m0, long b0){ m = m0; b = b0; }
    }
    static String next () throws IOException {
        while (st == null || !st.hasMoreTokens())
            st = new StringTokenizer(br.readLine().trim());
        return st.nextToken();
    }
    static long readLong () throws IOException {
        return Long.parseLong(next());
    }
    static int readInt () throws IOException {
        return Integer.parseInt(next());
    }
    static double readDouble () throws IOException {
        return Double.parseDouble(next());
    }
    static char readCharacter () throws IOException {
        return next().charAt(0);
    }
    static String readLine () throws IOException {
        return br.readLine().trim();
    }
}