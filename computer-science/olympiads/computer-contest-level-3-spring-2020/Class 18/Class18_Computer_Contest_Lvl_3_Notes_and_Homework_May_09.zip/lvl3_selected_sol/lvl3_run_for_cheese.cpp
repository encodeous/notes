#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int MM = 2002;
int N, L; ll dp[MM][MM][2]; vector<int> p;
int main(){
    scanf("%d %d", &N, &L);
    for(int i=1, x; i<=N; i++){
        scanf("%d", &x); p.push_back(x);
    }
    p.push_back(L); N++; sort(p.begin(), p.end());
    int st = lower_bound(p.begin(), p.end(), L) - p.begin();
    memset(dp, 0x3f, sizeof(dp)); dp[st][st][0]=dp[st][st][1]=0;
    for(int len=1; len<=N; len++){
        for(int l=0; l+len<N; l++){
            int r = l + len;
            dp[l][r][0] = min(dp[l][r][0], dp[l+1][r][0]+1LL*(N-len)*(p[l+1]-p[l]));
            dp[l][r][0] = min(dp[l][r][0], dp[l+1][r][1]+1LL*(N-len)*(p[r]-p[l]));
            dp[l][r][1] = min(dp[l][r][1], dp[l][r-1][0]+1LL*(N-len)*(p[r]-p[l]));
            dp[l][r][1] = min(dp[l][r][1], dp[l][r-1][1]+1LL*(N-len)*(p[r]-p[r-1]));
        }
    }
    printf("%lld\n", min(dp[0][N-1][0], dp[0][N-1][1]));
}