#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
int n, num[202], dp[202][202];
int main(){
    while(scanf("%d", &n) && n){
        for(int i=1; i<=n; i++)
            scanf("%d", &num[i]);
        memset(dp, 0, sizeof(dp));
        for(int len=2; len<n; len++){
            for(int i=1; i<n; i++){
                int j=i+len;
                if(j > n) break;
                for(int k=i+1; k<j; k++)
                    dp[i][j]=max(dp[i][j], dp[i][k]+dp[k][j]+num[i]+num[k]+num[j]);
            }
        }
        printf("%d\n", dp[1][n]);
    }
}