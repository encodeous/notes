#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int N; ll a[402], dp[402][402];
int main(){
    scanf("%d", &N);
    for(int i=1; i<=N; i++){
        scanf("%lld", &a[i]); a[i] += a[i-1];
    }
    for(int len = 1; len < N ; len++){
        for(int i=1; i+len <= N; i++){
            int j = i + len;  dp[i][j] = dp[i+1][j];
            for(int k=i; k<j; k++){
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k+1][j]);
            }
            dp[i][j] += a[j] - a[i-1];
        }
    }
    printf("%lld\n", dp[1][N]);
}