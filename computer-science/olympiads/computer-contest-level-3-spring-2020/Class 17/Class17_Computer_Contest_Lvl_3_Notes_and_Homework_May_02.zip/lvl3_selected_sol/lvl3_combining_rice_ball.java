import java.util.*;
import java.io.*;
public class homework {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static StringTokenizer st;
	public static void main(String[] args) throws IOException {
		int n = readInt(), psa[] = new int[n+1], ans = 0; boolean dp[][] = new boolean[n+1][n+1];
		for(int i=1; i<=n; i++) {
			psa[i] = readInt();	ans = Math.max(ans, psa[i]);
			psa[i] += psa[i-1]; dp[i][i] = true;
		}
		for(int len=1; len<n; len++) {
			for(int lft=1; lft+len<=n; lft++) {
				int rit = lft + len;
				for(int p=lft, q=rit; p<q; ) {
					int lsum = psa[p] - psa[lft-1], rsum = psa[rit] - psa[q-1];
					if(dp[lft][p] && dp[q][rit] && lsum == rsum && (p+1==q || dp[p+1][q-1])) {
						dp[lft][rit] = true; ans = Math.max(ans, psa[rit] - psa[lft-1]);
					}
					if(lsum < rsum) p++;
					else q--;
				}
			}
		}
		System.out.println(ans);
	}
	static String next() throws IOException {
		while (st == null || !st.hasMoreTokens()) 
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong() throws IOException {
		return Long.parseLong(next());
	}
	static int readInt() throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble() throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter() throws IOException {
		return next().charAt(0);
	}
	static String readLine() throws IOException {
		return br.readLine().trim();
	}
}