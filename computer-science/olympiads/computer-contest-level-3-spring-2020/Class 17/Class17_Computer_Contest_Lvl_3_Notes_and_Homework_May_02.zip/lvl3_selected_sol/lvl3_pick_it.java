import java.util.*;
public class dmoj_pickit {
	static int N;
	static int [][]dp;
	public static void main(String [] args){
		Scanner in = new Scanner(System.in);
		dp = new int[205][205];
		while(true){
			N = in.nextInt();
			if(N == 0) break;
			for(int i=0; i<205; i++)
				Arrays.fill(dp[i], -1);
			int [] a = new int [N+1];
			for(int i=1; i<=N; i++)
				a[i] = in.nextInt();
			System.out.println(fun(a, 1, N));
		}
	}
	static int fun(int []a, int L, int R){
		if(dp[L][R]!=-1) return dp[L][R];
		if(L+1==R) return dp[L][R] = 0;
		for(int mid=L+1; mid<R; mid++)
			dp[L][R]=Math.max(dp[L][R], fun(a, L, mid)+fun(a, mid, R)+a[L]+a[mid]+a[R]);
		return dp[L][R];
	}
}