#include <bits/stdc++.h>
using namespace std;
int N, M, pos[1000002]; vector<int> lis;
int main(){
    scanf("%d", &N);
    for(int i=1, x=0; i<=N; i++){
        scanf("%d", &x); pos[x] = i;
    }
    scanf("%d", &M);
    for(int i=1, x=0; i<=M; i++){
        scanf("%d", &x);
        if(pos[x]==0) continue;
        if(lis.empty() || lis.back()<pos[x]) lis.push_back(pos[x]);
        else{
            int p = lower_bound(lis.begin(), lis.end(), pos[x]) - lis.begin();
            lis[p] = pos[x];
        }
    }
    printf("%d\n", lis.size());
}