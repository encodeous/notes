#include <bits/stdc++.h>
using namespace std;
int N, M, dp[1002][1002]; char s[1002], t[1002];
int main(){
    scanf("%d %d %s %s", &N, &M, s+1, t+1);
    memset(dp, 0x3f, sizeof(dp)); dp[0][0] = 0;
    for(int i=1; i<=max(N, M); i++){
        dp[0][i] = dp[i][0] = (i+2)/3;
    }
    for(int i=1; i<=N; i++){
        for(int j=1; j<=M; j++){
            if(s[i] == t[j]) dp[i][j] = dp[i-1][j-1];
            else dp[i][j] = dp[i-1][j-1] + 1;
            for(int k=1; k<=3; k++){
                if(i >= k) dp[i][j] = min(dp[i][j], dp[i-k][j] + 1);
                if(j >= k) dp[i][j] = min(dp[i][j], dp[i][j-k] + 1);
            }
        }
    }
    printf("%d\n", dp[N][M]);
}