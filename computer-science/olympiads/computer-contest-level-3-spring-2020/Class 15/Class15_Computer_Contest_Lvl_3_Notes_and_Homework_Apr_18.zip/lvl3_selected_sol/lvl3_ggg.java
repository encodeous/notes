import java.util.*;
import java.io.*;
public class Test{
	public static void main(String [] args) throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int [] pos = new int [1000001];
		int [] lis = new int [1000001];
		int N = Integer.parseInt(br.readLine());
		StringTokenizer st = new StringTokenizer(br.readLine());
		for(int i=1; i<=N; i++){
			int x = Integer.parseInt(st.nextToken());
			pos[x] = i;
		}
		int M = Integer.parseInt(br.readLine()), cnt=0;
		st = new StringTokenizer(br.readLine());
		for(int i=1; i<=M; i++){
			int x = Integer.parseInt(st.nextToken());
			if(pos[x]==0) continue;
			if(cnt == 0 || lis[cnt-1] < pos[x]) lis[cnt++] = pos[x];
			else{
				int p = Arrays.binarySearch(lis, 0, cnt, pos[x]);
				if(p < 0){
					lis[-(p+1)] = pos[x];
				}
			}
		}
		System.out.println(cnt);
	}
}