#include <bits/stdc++.h>
using namespace std;
typedef pair<int, int> pi;
int N, S, h[52], e[52], p[52]; pi dp[2][1002];
int main(){
    cin >> N;
    for(int i=1; i<=N; i++) cin >> h[i] >> e[i] >> p[i];
    cin >> S;
    for(int i=1; i<=N; i++){
        for(int j=0; j<=S; j++) dp[i%2][j] = dp[(i-1)%2][j];
        for(int v=0, w=p[i], cnt=1; h[i] > 0 && w <= S; h[i] -= e[i], w += p[i], cnt++){
            v += h[i];
            for(int j=0; j<=S; j++){
                if(j >= w) {
                    int val = dp[(i-1)%2][j - w].first + v, len = dp[(i-1)%2][j-w].second + cnt;
                    if(val > dp[i%2][j].first) dp[i%2][j] = {val, len};
                    else if(val == dp[i%2][j].first && len < dp[i%2][j].second) dp[i%2][j] = {val, len};
                }
            }
        }
    }
    cout << dp[N%2][S].first << "\n" << dp[N%2][S].second << "\n";
}