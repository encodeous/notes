import java.util.*;
import java.io.*;
public class Test {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static PrintWriter pr = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
	static StringTokenizer st;
	public static void main(String[] args) throws IOException {
		int n = readInt(), h[] = new int[n+1], e[] = new int[n+1], p[] = new int[n+1];
		for(int i=1; i<=n; i++) {
			h[i] = readInt(); e[i] = readInt(); p[i] = readInt();
		}
		int W = readInt(), dp[][] = new int[2][W+1], t[][] = new int[2][W+1];
		for(int i=1; i<=n; i++) {
			for(int j=0; j<=W; j++) {
				dp[i%2][j] = dp[(i-1)%2][j]; t[i%2][j] = t[(i-1)%2][j];
			}
			for(int v=0, w=p[i], cnt=1; h[i] > 0 && w <= W; h[i]-=e[i], w+=p[i], cnt++) {
				v += h[i]; 
				for(int j=0; j<=W; j++) {
					if(j >= w) {
						int val = dp[(i-1)%2][j - w] + v, dur = t[(i-1)%2][j-w] + cnt;
						if(val > dp[i%2][j]) {
							dp[i%2][j] = val; t[i%2][j] = dur;
						}else if(val == dp[i%2][j] && dur < t[i%2][j]) {
							t[i%2][j] = dur;
						}
					}
				}
			}
		}
		System.out.println(dp[n%2][W] + "\n" + t[n%2][W]);
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}