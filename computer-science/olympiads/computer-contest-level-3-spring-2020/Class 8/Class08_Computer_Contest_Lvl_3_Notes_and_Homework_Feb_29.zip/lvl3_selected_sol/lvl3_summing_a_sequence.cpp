#include <bits/stdc++.h>
using namespace std;
int N; long long dp[1000002];
int main(){
    scanf("%d %lld", &N, &dp[1]); dp[1] = max(0LL, dp[1]);
    for(int i=2, x; i<=N; i++){
        scanf("%d", &x); dp[i] = max(dp[i-1], dp[i-2]+x);
    }
    printf("%lld\n", dp[N]);
}