import java.util.*;
public class dmoj_notenoughtime {
	public static void main(String []args){
		Scanner in = new Scanner(System.in);
		int N = in.nextInt(), T = in.nextInt();
		int [] dp = new int[T+1];
		for(int i=1; i<=N; i++){
			int p0=in.nextInt(), v0=in.nextInt(), p1=in.nextInt(), v1=in.nextInt();
			int p2=in.nextInt(), v2=in.nextInt();
			for(int j=T; j>=0; j--){
				if(j >= p0) dp[j] = Math.max(dp[j], dp[j-p0]+v0);
				if(j >= p1) dp[j] = Math.max(dp[j], dp[j-p1]+v1);
				if(j >= p2) dp[j] = Math.max(dp[j], dp[j-p2]+v2);
			}
		}
		System.out.println(dp[T]);
	}
}