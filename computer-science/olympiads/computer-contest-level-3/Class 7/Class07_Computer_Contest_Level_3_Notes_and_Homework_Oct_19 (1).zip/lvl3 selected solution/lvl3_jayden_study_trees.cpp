#include <bits/stdc++.h>
using namespace std;
int N, len, root; vector<int> adj[10002]; bool vis[10002];
void DFS(int u, int dis){
    vis[u] = true;
    if(dis > len){ len=dis; root=u; }
    for(int v: adj[u])
        if(!vis[v]) DFS(v, dis+1);
}
int main(){
    scanf("%d", &N);
    for(int i=1, x=0, y=0; i<N; i++){
        scanf("%d %d", &x, &y);
        adj[x].push_back(y); adj[y].push_back(x);
    }
    len=0; DFS(1, 0);
    memset(vis, 0, sizeof(vis));
    len=0; DFS(root, 0);
    printf("%d\n", len);
}