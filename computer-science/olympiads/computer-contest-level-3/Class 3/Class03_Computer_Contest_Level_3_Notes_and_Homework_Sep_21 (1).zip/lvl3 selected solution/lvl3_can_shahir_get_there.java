import java.util.*;
import java.io.*;
public class Test {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static PrintWriter pr = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
	static StringTokenizer st;
	public static void main(String[] args) throws IOException {
		int N = readInt(), M = readInt(), A = readInt(), B = readInt();
		List<Integer> adj[] = new ArrayList[N+1];
		for(int i=0; i<=N; i++) adj[i] = new ArrayList();  // create adjacency list
		for(int i=1; i<=M; i++) {
			int x = readInt(), y = readInt();   // add edge x --- y
			adj[x].add(y); adj[y].add(x);
		}
		Queue<Integer> Q = new LinkedList();  // Queue for BFS
		boolean vis[] = new boolean[N+1]; // visited array
		int dis[] = new int[N+1]; // distance array
		int pre[] = new int[N+1]; // previous array to track the path
		Q.add(A); vis[A]=true; dis[A]=0; pre[A] = -1; //BFS initialization
		while(! Q.isEmpty() ) {
			int cur = Q.poll();
			for(int nxt: adj[cur]) { // loop every adjacent vertex
				if(!vis[nxt]) { //found new vertex nxt
					Q.add(nxt); vis[nxt]=true; dis[nxt] = dis[cur]+1;  pre[nxt] = cur;
				}
			}
		}
		System.out.println(vis[B]? "GO SHAHIR!": "NO SHAHIR!"); //check if there is a path to B
		//for(int i=B; i!=-1; i=pre[i]) System.out.print(i + "<---");
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}