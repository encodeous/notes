#include <bits/stdc++.h>
using namespace std;
int N, dist[10005];
vector<int> adj[10005], ed;
bool vis[10005];
int main() {
    cin>>N;
    for(int i=1; i<=N; i++) {
        int M;
        cin>>M;
        if(M==0) ed.push_back(i);
        for(int j=0; j<M; j++) {
            int x;
            cin>>x;
            adj[i].push_back(x);
        }
    }
    queue<int>q;
    memset(dist, 0x3f, sizeof(dist));
    q.push(1); vis[1]=true; dist[1]=1;
    while(!q.empty()) {
        int u = q.front();
        q.pop();
        for(int v : adj[u]) {
            if(!vis[v]) {
                vis[v]=true;
                dist[v] = dist[u]+1;
                q.push(v);
            }
        }
    }
    bool flag=true;
    for(int i=1; i<=N; i++)
        flag &= vis[i];
    cout<<(flag? "Y" : "N")<<endl;
    int ans=2e9;
    for(int i: ed)
        ans = min(ans, dist[i]);
    cout<<ans<<endl;
}