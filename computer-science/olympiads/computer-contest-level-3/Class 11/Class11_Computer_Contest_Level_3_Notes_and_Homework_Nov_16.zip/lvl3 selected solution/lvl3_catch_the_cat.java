import java.util.*;
import java.io.*;
public class Test {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static StringTokenizer st;
	public static void main(String[] args) throws IOException {
		int X = readInt(), Y = readInt(), limit = 100001, dis[] = new int[limit]; 
		boolean vis[] = new boolean [limit];
		Queue<Integer> Q = new LinkedList();
		Q.add(X); dis[X] = 0; vis[X] = true;
		while(!Q.isEmpty()) {
			int cur = Q.poll(), nxt = 0;
			for(int i=0; i<3; i++) {
				if(i==0) nxt = cur - 1;
				else if(i==1) nxt = cur + 1;
				else nxt = cur * 2;
				if(nxt >= 0 && nxt <limit && !vis[nxt]) {
					Q.add(nxt); vis[nxt]=true; dis[nxt] = dis[cur] + 1;
				}
			}
			if(vis[Y]) { System.out.println(dis[Y]); return; }
		}
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}