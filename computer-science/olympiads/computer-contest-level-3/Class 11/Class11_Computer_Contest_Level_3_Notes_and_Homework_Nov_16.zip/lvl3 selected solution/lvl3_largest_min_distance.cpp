#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int MM = 1e5+5;
int N, M, p[MM];
bool check(int x){
    int cnt = 1, lst = p[0];
    for(int i=1; i<N; i++){
        if(p[i] - lst >= x){ cnt++; lst = p[i]; }
    }
    return cnt >= M;
}
int main(){
    scanf("%d %d", &N, &M);
    for(int i=0; i<N; i++) scanf("%d", &p[i]);
    sort(p, p+N);
    int lo = 1, hi = 1e9, ans = 0;
    while(lo <= hi){
        int mid = lo + (hi - lo)/2;
        if(check(mid)) { ans = mid; lo = mid + 1;}
        else  hi = mid - 1;
    }
    printf("%d\n", ans);
}
