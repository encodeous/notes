import java.util.*;
import java.io.*;
public class Test {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static PrintWriter pr = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
	static StringTokenizer st;
	public static void main(String[] args) throws IOException {
		int N = readInt(), freq[] = new int[1001];
		for(int i=0; i<N; i++) freq[readInt()]++;
		int max = -1, hival = 0, loval = 0;
		for(int i=1; i<=1000; i++) {
			if(freq[i] > max) {
				max = freq[i]; hival = loval = i;
			}else if(freq[i] == max) {
				hival = i;
			}
		}
		if(hival != loval) { System.out.println(hival - loval); return; }
		int max2 = -1, hival2 = 0, loval2 = 0;
		for(int i=1; i<=1000; i++) {
			if(freq[i] < max && freq[i] > max2) {
				max2 = freq[i]; hival2 = loval2 = i;
			}else if(freq[i] < max && freq[i] == max2) {
				hival2 = i;
			}
		}
		System.out.println(Math.max(Math.abs(hival - hival2),  Math.abs(hival - loval2)));
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}