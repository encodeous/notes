import java.util.*;
public class an_array_problem {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int n = in.nextInt();
		if(n == 1) { System.out.println(0); return;};
		int a[] = new int[n]; long sum = 0, mx = 0;
		for(int i=0; i<n; i++){
			a[i] = in.nextInt();
			sum += a[i]; mx = Math.max(mx, a[i]);
		}
		long ans = 0;
		if(mx > sum - mx) System.out.println(sum-mx);
		else System.out.println(sum/2);
	}
}