import java.util.*;
import java.io.*;
public class aplusb {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static StringTokenizer st;
	static int n, q, p[]; //p is parent array
	public static void main(String[] args) throws IOException {
		n = readInt(); q = readInt(); p = new int[n+1];
		for(int i=1; i<=n; i++) p[i] = i;  //create set
		for(int i=1; i<=q; i++){
			String op = next(); int x = readInt(), y = readInt();
			int fx = find(x), fy = find(y);
			if(op.equals("A")){
				if(fx != fy) { p[fx] = fy; }
			}else{
				if(fx == fy) System.out.println("Y");
				else System.out.println("N");
			}
		}
	}
	static int find(int d){
		if(d != p[d]) p[d] = find(p[d]);
		return p[d];
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}