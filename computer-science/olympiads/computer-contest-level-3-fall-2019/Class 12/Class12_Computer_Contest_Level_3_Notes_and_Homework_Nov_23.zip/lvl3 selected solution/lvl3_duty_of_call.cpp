#include <bits/stdc++.h>
using namespace std;
const int MM = 1e6+2;
int N, R, val[MM], cnt1, cnt2; vector<int> adj[MM]; bool in[MM];
void dfs(int u, int clr) {
    val[u] = clr; ;
    for(int v: adj[u])
        if(val[v]==0) dfs(v, -clr);
}
int main(){
    scanf("%d %d", &N, &R);
    for(int i=1, k, x; i<=N; i++){
        scanf("%d", &k);
        for(int j=1; j<=k; j++){
            scanf("%d", &x); in[x] = 1;
            adj[i].push_back(x); adj[x].push_back(i);
        }
    }
    dfs(R, -1);
    for(int i=1; i<=N; i++){
        if(val[i]<0 && !in[i]) cnt1++;
        if(val[i]>0 && !in[i]) cnt2++;
    }
    printf("%d %d\n", cnt1, cnt2);
}