#include <bits/stdc++.h>
using namespace std;
int M, cnt, in[2000]; unordered_map<string, int> mp; string name[2000], a, b;
vector<int> adj[2000];
int main(){
    cin >> M;
    for(int i=0; i<M; i++){
        cin >> a >> b;
        if(!mp.count(a)) { mp[a]=++cnt; name[cnt] = a; }
        if(!mp.count(b)) { mp[b]=++cnt; name[cnt] = b; }
        adj[mp[b]].push_back(mp[a]); in[mp[a]]++;
    }
    while(true){
        int id = -1;
        for(int i=1; i<=cnt; i++){
            if(in[i] == 0){ id = i; in[i]--; break;}
        }
        if(id == -1) break;
        cout << name[id] << "\n";
        for(int v: adj[id]) in[v]--;
    }
}