import java.util.*;
public class homework {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        while(true) {
        	int R = in.nextInt(), count = 0;
        	if(R == 0) break;
        	for(int x=0; x<=R; x++) {
        		int y = (int)Math.sqrt(R*R - x*x);
        		count += y;
        	}
        	System.out.println(4*count + 1);
        }
    }
}