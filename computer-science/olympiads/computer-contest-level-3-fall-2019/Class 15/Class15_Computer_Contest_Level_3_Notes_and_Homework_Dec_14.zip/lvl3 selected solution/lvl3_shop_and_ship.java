import java.util.*;
import java.io.*;
public class Test {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static PrintWriter pr = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
	static StringTokenizer st;
	public static void main(String[] args) throws IOException {
		int N = readInt(), M = readInt(), adj[][] = new int[N+1][N+1];
		for(int i=1; i<=N; i++) Arrays.fill(adj[i], (int)1e9);
		for(int i=1; i<=M; i++) {
			int u = readInt(), v = readInt(), w = readInt();
			adj[u][v] = adj[v][u] = w;
		}
		int K = readInt(), a[] = new int[K], b[] = new int[K];
		for(int i=0; i<K; i++) {
			a[i] = readInt(); b[i] = readInt();
		}
		int D = readInt(), dis[] = new int[N+1]; boolean vis[] = new boolean[N+1];
		Arrays.fill(dis, (int)1e9);  dis[D] = 0;
		for(int k=1; k<=N; k++) {
			int min = (int)1e9, id = -1;
			for(int i=1; i<=N; i++) {
				if(!vis[i] && dis[i] < min) { min = dis[i]; id = i; }
			}
			if(id == -1) break;
			vis[id] = true;
			for(int v=1; v<=N; v++) {
				if(!vis[v] && dis[v] > dis[id] + adj[id][v]) dis[v] = dis[id] + adj[id][v];
			}
		}
		int ans = (int)1e9;
		for(int i=0; i<K; i++)
			if(dis[a[i]] + b[i] < ans) ans = dis[a[i]] + b[i];
		System.out.println(ans);
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}