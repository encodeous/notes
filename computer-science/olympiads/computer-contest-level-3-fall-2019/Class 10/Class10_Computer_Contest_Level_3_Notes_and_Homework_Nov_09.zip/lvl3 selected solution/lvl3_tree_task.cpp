#include <bits/stdc++.h>
using namespace std;
typedef pair<int, int> pi;
const int MM = 5e5+5;
int N, far, len, pre[MM], cost[MM], d, r = 1e9, p1, p2; vector<pi> adj[MM];
void dfs(int u, int pa, int dis){
    if(dis > len) { len = dis; far = u; }
    for(pi e: adj[u]){
        int v = e.first, w = e.second;
        if(v != pa) {
            pre[v] = u; cost[v] = w; dfs(v, u, dis+w);
        }
    }
}
int main(){
    //freopen("test.txt", "r", stdin);
    scanf("%d", &N);
    for(int i=1, u, v, w; i<N; i++){
        scanf("%d %d %d", &u, &v, &w);
        assert(0<=u && u<=N && 0<=v && v<=N);
        adj[u].push_back({v, w}); adj[v].push_back({u, w});
    }
    len = -1; dfs(1, 0, 0); len = -1; dfs(p1=far, 0, 0); d = len; p2 = far;
    for(int x=0; p2!=p1; p2 = pre[p2]){
        r = min(r, max(x, d-x)); x += cost[p2];
    }
    printf("%d\n%d\n", d, r);
}