#include <bits/stdc++.h>
using namespace std;
int N, a[200002], ans=1e9, vis[200002], dis[200002];
void dfs(int u, int d){
    vis[u] = 1; dis[u] = d; int v = a[u];
    if(vis[v] == 1) ans = min(ans, dis[u]-dis[v]+1);
    else if(vis[v] == 0) dfs(v, d+1);
    vis[u] = 2;
}
int main(){
    //freopen("test.txt", "r", stdin);
    scanf("%d", &N);
    for(int i=1; i<=N; i++) scanf("%d", &a[i]);
    for(int i=1; i<=N; i++){
        if(!vis[i]) dfs(i, 1);
    }
    printf("%d\n", ans);
}