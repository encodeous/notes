#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll p, y, t, ans;
bool check(ll x){
    ll tot = 0;
    for(int i=1; i<=y; i++){
        tot = tot + x;
        tot += tot*p/100;
        if(tot >= t) return true;
    }
    return false;
}
int main(){
    scanf("%lld %lld %lld", &p, &y, &t);
    ll lo = 1, hi = t;
    while(lo <= hi){
        ll mid = (lo + hi)/2;
        if(check(mid)) { ans = mid; hi = mid-1; }
        else lo = mid + 1;
    }
    printf("%lld\n", ans);
}