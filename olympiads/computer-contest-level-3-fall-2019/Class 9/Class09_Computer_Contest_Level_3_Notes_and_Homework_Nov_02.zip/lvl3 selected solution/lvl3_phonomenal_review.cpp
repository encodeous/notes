#include <bits/stdc++.h>
using namespace std;
const int MM = 1e5+5;
int N, M, len, far, rt; vector<int> adj[MM]; bool pho[MM];
bool dfs1(int u, int pre) {
    for(int v: adj[u])
        if(v != pre){
            if(dfs1(v, u)) pho[u] = true;
        }
    if(!pho[u]) N--;
    return pho[u];
}
void dfs2(int u, int pre, int dis) {
    if(dis > len) { len = dis; far = u; }
    for(int v: adj[u])
        if(v!=pre && pho[v]) dfs2(v, u, dis+1);
}
int main(){
    scanf("%d %d", &N, &M);
    for(int i=1; i<=M; i++){
        scanf("%d", &rt); pho[rt] = true;
    }
    for(int i=1, u, v; i<N; i++) {
        scanf("%d %d", &u, &v);
        adj[u].push_back(v); adj[v].push_back(u);
    }
    dfs1(rt, -1);  len = 0; dfs2(rt, -1, 0);  len = 0; dfs2(far, -1, 0);
    printf("%d\n", 2*(N-1) - len);
}
