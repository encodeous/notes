import java.util.*;
import java.io.*;
import java.math.*;
public class homework {
    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    static StringTokenizer st;
    public static void main(String[] args) throws IOException{
    	char s[] = readLine().toCharArray(); int n = s.length, dp[][] = new int[n][n];
    	for(int i=0; i<n; i++) dp[i][i] = 1;
    	for(int len = 1; len<n; len++) {
    		for(int lft = 0; lft + len <n; lft++) {
    			int rit = lft + len; dp[lft][rit] = n+1;
    			if((s[lft]=='(' && s[rit]==')') || (s[lft]=='[' && s[rit]==']')) dp[lft][rit] = dp[lft+1][rit-1];
    			for(int k = lft; k < rit; k++) 
    				dp[lft][rit] = Math.min(dp[lft][rit], dp[lft][k] + dp[k+1][rit]);
    		}
    	}
    	System.out.println(dp[0][n-1]);
    }
    static String next () throws IOException {
        while (st == null || !st.hasMoreTokens())
            st = new StringTokenizer(br.readLine().trim());
        return st.nextToken();
    }
    static long readLong () throws IOException {
        return Long.parseLong(next());
    }
    static int readInt () throws IOException {
        return Integer.parseInt(next());
    }
    static double readDouble () throws IOException {
        return Double.parseDouble(next());
    }
    static char readCharacter () throws IOException {
        return next().charAt(0);
    }
    static String readLine () throws IOException {
        return br.readLine().trim();
    }
}