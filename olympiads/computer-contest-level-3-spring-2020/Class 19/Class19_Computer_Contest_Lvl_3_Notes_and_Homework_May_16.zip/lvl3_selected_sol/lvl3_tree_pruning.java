import java.util.*;
import java.io.*;
import java.math.*;
public class homework {
    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    static StringTokenizer st;
    public static void main(String[] args) throws IOException{
    	int n = readInt(); long k = readLong(), w[] = new long[n+1], sum =0;
    	List<Integer> adj[] = new ArrayList[n+1];
    	for(int i=1; i<=n; i++) { w[i] = readLong(); adj[i] = new ArrayList(); sum += w[i];}
    	if(sum < k) { System.out.println(-1); return; }
    	for(int i=1; i<n; i++) {
    		int u = readInt(), v = readInt();
    		adj[u].add(v); adj[v].add(u);
    	}
    	boolean vis[] = new boolean[n+1]; List<Integer> ans = new ArrayList();
    	for(int u=1; u<=n; u++) {
    		if(vis[u]) continue;
    		sum = 0; ans.clear(); Queue<Integer> q = new LinkedList();
    		q.add(u); sum += w[u];  vis[u] = true; ans.add(u);
    		while(!q.isEmpty()) {
    			int cur = q.poll();
    			for(int nxt: adj[cur]) {
    				if(!vis[nxt] && sum + w[nxt] <= 2*k) {
    					sum += w[nxt]; q.add(nxt); vis[nxt]=true; ans.add(nxt);
    				}
    			}
    		}
    		if(sum >= k && sum <= 2*k) {
    			System.out.println(ans.size());
    			for(int x: ans) System.out.print(x + " ");
    			return;
    		}
    	}
    	System.out.println(-1);
    }
    static String next () throws IOException {
        while (st == null || !st.hasMoreTokens())
            st = new StringTokenizer(br.readLine().trim());
        return st.nextToken();
    }
    static long readLong () throws IOException {
        return Long.parseLong(next());
    }
    static int readInt () throws IOException {
        return Integer.parseInt(next());
    }
    static double readDouble () throws IOException {
        return Double.parseDouble(next());
    }
    static char readCharacter () throws IOException {
        return next().charAt(0);
    }
    static String readLine () throws IOException {
        return br.readLine().trim();
    }
}