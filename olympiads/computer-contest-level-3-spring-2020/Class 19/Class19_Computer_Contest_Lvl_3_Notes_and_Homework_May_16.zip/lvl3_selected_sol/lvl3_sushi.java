import java.util.*;
import java.io.*;
import java.math.*;
public class homework {
    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    static StringTokenizer st;
    static int n, f[] = new int[4]; static double dp[][][];
    public static void main(String[] args) throws IOException{
    	n = readInt(); dp = new double[n+1][n+1][n+1];
    	for(int i=1; i<=n; i++) f[readInt()]++;
    	System.out.printf("%.9f\n", fun(f[1], f[2], f[3]));
    }
    static double fun(int d1, int d2, int d3) {
    	if(d1 == 0 && d2 == 0 && d3 == 0) return 0;
    	if(dp[d1][d2][d3] > 0.0) return dp[d1][d2][d3];
    	double ret = n; int t = d1 + d2 + d3;
    	if(d1 > 0) ret += d1 * fun(d1-1, d2, d3);
    	if(d2 > 0) ret += d2 * fun(d1+1, d2-1, d3);
    	if(d3 > 0) ret += d3 * fun(d1, d2+1, d3-1);
    	return dp[d1][d2][d3] = ret / t;
    }
    static String next () throws IOException {
        while (st == null || !st.hasMoreTokens())
            st = new StringTokenizer(br.readLine().trim());
        return st.nextToken();
    }
    static long readLong () throws IOException {
        return Long.parseLong(next());
    }
    static int readInt () throws IOException {
        return Integer.parseInt(next());
    }
    static double readDouble () throws IOException {
        return Double.parseDouble(next());
    }
    static char readCharacter () throws IOException {
        return next().charAt(0);
    }
    static String readLine () throws IOException {
        return br.readLine().trim();
    }
}