import java.util.*;
import java.io.*;
public class homework {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static PrintWriter pr = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
	static StringTokenizer st;
	static int n; static List<pt> p = new ArrayList(); static long ans = 0;
	public static void main(String[] args) throws IOException {
		n = readInt();
		for(int i=0; i<n; i++) p.add(new pt(readInt(), readInt()));
		for(int k=0; k<4; k++) { solve(); rotate();  /* (x,y) (-x, -y)(y,-x)(-y, x) */}
		System.out.println(ans);
	}
	static void solve() {
		Collections.sort(p); int mv = 10003, mod = (int)1e9+7;
		long [] sx=new long[2*mv], sy=new long[2*mv], cx=new long[2*mv], cy=new long[2*mv], lx=new long[2*mv], ly=new long[2*mv];
		for(pt e: p) {
			int x = e.x + mv, y = e.y + mv;
			sx[x] = (sx[x] + (y-lx[x]) * cx[x]) % mod;
			sy[y] = (sy[y] + (x-ly[y]) * cy[y]) % mod;
			cx[x]++; cy[y]++; lx[x]=y;  ly[y]=x;
			ans = (ans + sx[x]*sy[y]) % mod;
		}
	}
	static void rotate() {
		for(int i=0; i<p.size(); i++) {
			int x = p.get(i).x, y = p.get(i).y;
			p.set(i, new pt(y, -x));
		}
	}
	static class pt implements Comparable<pt>{
		int x, y;
		pt(int x0, int y0) { x = x0; y = y0; }
		public int compareTo(pt a) { 
			if(x != a.x) return x - a.x;
			return y - a.y;
		}
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}