#include<bits/stdc++.h>
using namespace std;
const int MM = 2005;
int N, dp[MM][MM]; char g[MM][MM]; long long tot;
int main(){
    cin >> N;
    for(int i=1; i<=N; i++)
        for(int j=1; j<=N; j++)
            cin >> g[i][j];
    for(int i=N; i>=1; i--){
        for(int j=1; j<=N; j++){
            if(g[i][j]=='.') continue;
            dp[i][j] = 1 + min(dp[i+1][j-1], min(dp[i+1][j], dp[i+1][j+1]));
            tot += dp[i][j];
        }
    }
    cout << tot;
}