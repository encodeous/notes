import java.util.*;
public class test {
	public static void main(String[] args){
		Scanner in = new Scanner (System.in);
		int T = in.nextInt(), a[][]=new int[5][5];
		a[1][0] = a[2][0] = a[3][0] = a[2][1] = 1;
		a[1][1] = a[2][2] = a[3][1] = -1;
		for(int t=1; t<=T; t++){
			int m = in.nextInt(), x = in.nextInt(), y = in.nextInt();
			for(int i=m; i>=1; i--){
				int blockSz = (int)Math.pow(5, i-1), bx = x / blockSz, by = y / blockSz;
				if(a[bx][by] == 1){
					System.out.println("crystal"); break;
				}else if(a[bx][by] == 0){
					System.out.println("empty"); break;
				}else{
					if(i==1) { System.out.println("empty"); break; }
					x = x % blockSz; y = y % blockSz;
				}
			}
		}
	}
}