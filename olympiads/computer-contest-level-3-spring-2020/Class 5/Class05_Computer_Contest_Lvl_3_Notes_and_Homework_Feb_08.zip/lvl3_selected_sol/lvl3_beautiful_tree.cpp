#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int MM = 100002;
int N, d1[MM], d2[MM], len; vector<int> adj[MM]; bool f[MM]; ll v;
void dfs(int u, int pa){
    d1[u] = d2[u] = 0;
    for(int v: adj[u]){
        if(v == pa) continue;
        dfs(v, u);
        if(!f[v]) continue;
        if(d1[v]+1 > d1[u]){ d2[u] = d1[u]; d1[u] = d1[v]+1; }
        else if(d1[v]+1 > d2[u]) d2[u] = d1[v]+1;
    }
    if(!f[u]) { d1[u]=d2[u]=0; return; }
    if(d1[u] + 1 + d2[u] > len) len = d1[u] + 1 + d2[u];
}
int main(){
    //freopen("test.txt", "r", stdin);
    scanf("%d", &N);
    for(int i=1; i<=N; i++){
        scanf("%lld", &v); v=1+4*v; ll x = ll(sqrt(v)+0.5);
        if(x*x==v) f[i]=1;
    }
    for(int i=1, u, v; i<N; i++){
        scanf("%d %d", &u, &v);
        adj[u].push_back(v); adj[v].push_back(u);
    }
    dfs(1, 0); printf("%d\n", len);
}