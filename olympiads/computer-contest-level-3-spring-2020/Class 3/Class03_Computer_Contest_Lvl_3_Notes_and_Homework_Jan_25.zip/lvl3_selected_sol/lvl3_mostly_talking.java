import java.util.*;
import java.io.*;
public class Test {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static PrintWriter pr = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
	static StringTokenizer st;
	static int N, M; static long INF = (long)1e12;
	public static void main(String[] args) throws IOException {
		 N = readInt(); M = readInt(); 
		 List<edge> adj[] = new ArrayList[N+1], rev[] = new ArrayList[N+1];
		 for(int i=1; i<=N; i++) {
			 adj[i] = new ArrayList(); rev[i] = new ArrayList();
		 }
		 for(int i=1; i<=M; i++) {
			 int u = readInt(), v = readInt(); long w = readLong();
			 adj[u].add(new edge(v, w)); rev[v].add(new edge(u, w));
		 }
		 long dis1[] = new long[N+1], dis2[] = new long[N+1];
		 dijkstra(1, dis1, adj); dijkstra(N, dis2, rev);
		 long ans = dis1[N]; int D = readInt();
		 for(int i=1; i<=D; i++) {
			 int u = readInt(), v = readInt(), w = readInt();
			 if(dis1[u] + w + dis2[v] < ans) ans = dis1[u] + w + dis2[v];
		 }
		 System.out.println(ans >= INF? -1: ans);
	}
	static void dijkstra(int start, long dis[], List<edge>adj[]) {
		Arrays.fill(dis, INF);  dis[start] = 0;
		PriorityQueue<edge> q = new PriorityQueue();  q.add(new edge(start, 0));
		while(!q.isEmpty()) {
			edge cur = q.poll(); 
			if(cur.w > dis[cur.v]) continue;
			for(edge e: adj[cur.v]) {
				if(dis[e.v] > dis[cur.v] + e.w) {
					dis[e.v] = dis[cur.v] + e.w; q.add(new edge(e.v, dis[e.v]));
				}
			}
		}
	}
	static class edge implements Comparable<edge>{
		int v; long w;
		edge(int v0, long w0){ v=v0; w=w0;}
		public int compareTo(edge x) { return Long.compare(w, x.w); }
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}