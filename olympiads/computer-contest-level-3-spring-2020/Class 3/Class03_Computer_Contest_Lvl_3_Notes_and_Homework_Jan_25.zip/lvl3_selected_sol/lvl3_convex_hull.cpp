#include <cstdio>
#include <cstring>
#include <queue>
#include <vector>
#include <algorithm>
using namespace std;
int K,N,M,st,ed,dist[2002][202], ans=0x3f3f3f3f;
struct VT{
    int t,u,h;
    VT(){};
    VT(int t0, int u0, int h0){t=t0, u=u0, h=h0;};
    bool operator < (const VT &a) const{return t>a.t;}};
vector<VT> adj[2002];
inline void Read(int &a){
    char c=0, r=0, n=0; a=0;
    while(1){
        c=getchar();
        if((c=='-')&&!r) n=1;
        else if(c>='0'&&c<='9') a=a*10+c-'0', r=1;
        else if(r) break;
    }
    if(n) a=-a;
}
void dijkstra(){
    priority_queue<VT> Q;
    memset(dist, 0x3f, sizeof(dist));
    Q.push(VT(0, st, 0)); dist[st][0]=0;
    while(!Q.empty()){
        int t=Q.top().t, u=Q.top().u, h=Q.top().h; Q.pop();
        if(t>dist[u][h]) continue;
        for(int i=0; i<adj[u].size(); i++){
            int t1=adj[u][i].t, v=adj[u][i].u, h1=adj[u][i].h;
            if(h+h1>=K) continue;
            if(t+t1<dist[v][h+h1]){
                dist[v][h+h1]=t+t1;
                Q.push(VT(t+t1, v, h+h1));
            }
        }
    }
}
int main(){
    //freopen("test.txt", "r", stdin);
    Read(K), Read(N), Read(M);
    for(int i=0,a,b,t,h; i<M; i++){
        Read(a), Read(b), Read(t), Read(h);
        adj[a].push_back(VT(t, b, h));
        adj[b].push_back(VT(t, a, h));
    }
    Read(st), Read(ed);
    dijkstra();
    for(int i=0; i<K; i++)
        ans=min(ans, dist[ed][i]);
    if(ans==0x3f3f3f3f) printf("-1\n");
    else printf("%d\n", ans);
}

