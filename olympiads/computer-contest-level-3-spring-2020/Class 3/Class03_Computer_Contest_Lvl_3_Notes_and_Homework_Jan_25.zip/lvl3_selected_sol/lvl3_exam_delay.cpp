#include <bits/stdc++.h>
using namespace std;
typedef pair<double,int> pii;
int V, E, pre[1002]; double dis[1002]; bool vis[1002];
vector<pii> adj[1002];
priority_queue<pii, vector<pii>, greater<pii> > Q;
void dijkstra(int start){
    memset(pre, -1, sizeof(pre));
    fill(dis, dis+1002, 1e10);
    dis[start] = 0; Q.push(make_pair(0, start));
    while(!Q.empty()){
        int cur=Q.top().second; Q.pop();
        if(vis[cur]==0){
            vis[cur] = 1;
            for(int i=0; i<adj[cur].size(); i++){
                int v=adj[cur][i].second;
                double d=adj[cur][i].first;
                if(dis[v] > dis[cur] + d){
                    dis[v] = dis[cur] + d;
                    pre[v] = cur;
                    Q.push(make_pair(dis[v], v));
                }
            }
        }
    }
}
int main(){
    //freopen("test.txt", "r", stdin);
    cin >> V >> E;
    for(int i=0, u, v, w, s; i<E; i++){
        cin >> u >> v >> w >> s;
        adj[u].push_back(make_pair((double)w*60/s, v));
        adj[v].push_back(make_pair((double)w*60/s, u));
    }
    dijkstra(1);
    int cnt = 0;
    for(int i=V; i!=1; i=pre[i])
        cnt ++ ;
	int delay = (int)round(dis[V]/3.0);
    cout << cnt << endl << delay << endl;
}