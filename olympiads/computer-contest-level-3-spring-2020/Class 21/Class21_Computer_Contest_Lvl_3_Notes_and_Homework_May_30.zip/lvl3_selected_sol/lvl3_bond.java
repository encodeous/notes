import java.util.*;
import java.io.*;
import java.math.*;
public class homework {
    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    static StringTokenizer st;
    static int n; static double dp[], p[][];
    public static void main(String[] args) throws IOException{
    	n = readInt(); dp = new double[1<<n]; p = new double[n][n];
    	Arrays.fill(dp, -1.0);
    	for(int i=0; i<n; i++)
    		for(int j=0; j<n; j++)
    				p[i][j] = readInt()/100.0;
    	double ans = fun(0, 0)*100.0;
    	System.out.printf("%.9f\n", ans);
    }
    static double fun(int bond, int mask) {
    	if(dp[mask] >= 0.0) return dp[mask];
    	if(bond >= n) return 1.0;
    	double ret = 0.0;
    	for(int k=0; k<n; k++) {
    		if((mask & (1<<k)) == 0) ret = Math.max(ret,  p[bond][k] * fun(bond+1, mask | (1<<k)));
    	}
    	return dp[mask] = ret;
    }
    static String next () throws IOException {
        while (st == null || !st.hasMoreTokens())
            st = new StringTokenizer(br.readLine().trim());
        return st.nextToken();
    }
    static long readLong () throws IOException {
        return Long.parseLong(next());
    }
    static int readInt () throws IOException {
        return Integer.parseInt(next());
    }
    static double readDouble () throws IOException {
        return Double.parseDouble(next());
    }
    static char readCharacter () throws IOException {
        return next().charAt(0);
    }
    static String readLine () throws IOException {
        return br.readLine().trim();
    }
}