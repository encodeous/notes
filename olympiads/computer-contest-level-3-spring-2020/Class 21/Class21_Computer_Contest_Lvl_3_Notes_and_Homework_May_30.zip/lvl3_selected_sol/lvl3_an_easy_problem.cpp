#include <bits/stdc++.h>
using namespace std;
int n, dp[32], mx, ans;
int main(){
    cin >> n;
    for(int i=0, x; i<n; i++){
        cin >> x;   mx = 0;
        for(int j=0; j<=30; j++)
            if((x>>j) & 1) mx = max(mx, dp[j]+1);
        for(int j=0; j<=30; j++)
            if((x>>j) & 1) dp[j] = mx;
    }
    for(int i=0; i<=30; i++) ans = max(ans, dp[i]);
    cout << ans << endl;
}