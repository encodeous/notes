#include <bits/stdc++.h>
using namespace std;
int N, M, bit[52], res, use[1<<20], from[1<<20];
int dp[1<<20]; char g[22][52];
int main(){
    scanf("%d %d", &N, &M);
    for(int i=1; i<=N; i++){
        res <<= 1;
        for(int j=1; j<=M; j++){
            scanf(" %c", &g[i][j]);
            bit[j] = (bit[j]<<1) | (g[i][j]=='X');
            res = res | (g[i][j]=='X');
        }
    }
    if(res==0) { printf("1\n1\n"); return 0;}
    memset(dp, 0x3f, sizeof(dp));
    dp[0] = 0;
    for(int i=1; i<=M; i++){
        for(int j=0, tot=1<<N; j<tot; j++){
            int nkey = j | bit[i];
            if(dp[nkey] > dp[j] + 1){
                dp[nkey] = dp[j] + 1; use[nkey] = i; from[nkey] = j;
            }
        }
    }
    printf("%d\n", dp[res]);
    for(int key=res; key>0; key = from[key])
        printf("%d ", use[key]);
}