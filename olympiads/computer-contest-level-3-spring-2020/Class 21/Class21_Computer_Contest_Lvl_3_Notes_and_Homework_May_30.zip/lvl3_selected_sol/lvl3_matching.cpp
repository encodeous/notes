#include <bits/stdc++.h>
using namespace std;
int N, dp[1<<21], a[21][21], mod=1e9+7;
int fun(int man, int mask){
    if(man == N) return 1;
    if(dp[mask] != -1) return dp[mask];
    dp[mask] = 0;
    for(int k=0; k<N; k++)
        if((mask & 1<<k)==0 && a[man][k]== 1)
            dp[mask] = (dp[mask] + fun(man+1, mask|(1<<k)))%mod;
    return dp[mask];
}
int main(){
    cin >> N;
    for(int i=0; i<N; i++)
        for(int j=0; j<N; j++)
            cin >> a[i][j];
    memset(dp, -1, sizeof(dp));
    cout << fun(0, 0) << endl;
}