#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int MM = 5003;
int N, M, cnt[MM]; ll dp[MM], ans = -1e18;
int main(){
    scanf("%d %d", &N, &M);
    for(int i=1, n, v, p; i<=N; i++){
        scanf("%d %d %d", &n, &v, &p);
        memset(cnt, 0, sizeof(cnt));
        for(int j=v; j<MM; j++){
            if(dp[j] < dp[j-v] + p && cnt[j-v] + 1 <= n){
                dp[j] = dp[j-v] + p; cnt[j] = cnt[j-v] + 1;
            }
        }
    }
    for(int i=1; i<MM; i++) dp[i] = max(dp[i], dp[i-1]);
    for(int i=1, cap, fuel; i<=M; i++){
        scanf("%d %d", &cap, &fuel);
        ans = max(ans, dp[cap] - fuel);
    }
    printf("%lld\n", ans);
}