import java.io.*;
import java.util.*;
public class test {
   public static void main(String [] args){
	   Scanner in = new Scanner(System.in);
	   int n = in.nextInt(), a[] = new int[3], dp[] = new int[n+1];
	   Arrays.fill(dp, Integer.MIN_VALUE); dp[0] = 0;
	   for(int i=0; i<3; i++) {
		   a[i] = in.nextInt();
		   for(int j=a[i]; j<=n; j++) dp[j] = Math.max(dp[j], dp[j-a[i]] + 1);
	   }
	   System.out.println(dp[n]);
   }
}