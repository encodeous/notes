#include <bits/stdc++.h>
using namespace std;
const int MM=10004, MV=100004;
struct store{ int val, l, id; } a[MV];
int N, V, d[MM], dp[MM], ans[MV];
bool cmp(store x, store y){ return x.l < y.l; }
int main(){
    scanf("%d %d", &N, &V);
    for(int i=0; i<N; i++) scanf("%d", &d[i]);
    for(int i=0; i<V; i++){
        scanf("%d %d", &a[i].val, &a[i].l); a[i].id = i;
    }
    sort(a, a+V, cmp);  memset(dp, 0x3f, sizeof(dp));
    dp[0] = 0;
    for(int i=0, j=0; i<V; i++){
        for(; j<N && j<a[i].l; j++){
            for(int k=d[j]; k<MM; k++)
                dp[k] = min(dp[k], dp[k-d[j]] + 1);
        }
        ans[ a[i].id ] = ( dp[ a[i].val ] > MM? -1: dp[ a[i].val ] );
    }
    for(int i=0; i<V; i++) printf("%d\n", ans[i]);
}