import java.util.*;
import java.io.*;
public class Test {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static PrintWriter pr = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
	static StringTokenizer st;
	public static void main(String[] args) throws IOException {
		int N = readInt(), M = readInt(), w = 5000;
		long dp[] = new long[w + 2]; 
		for(int i=1; i<=N; i++) {
			int n = readInt(), v = readInt(), p = readInt();
			int cnt[] = new int[w + 2];
			for(int j=v; j<=w; j++) {
				if(dp[j-v] + p > dp[j] && cnt[j-v] + 1 <= n) {
					dp[j] = dp[j-v] + p; cnt[j] = cnt[j-v] + 1;
				}
			}
		}
		for(int i=1; i<=w; i++) dp[i] = Math.max(dp[i], dp[i-1]);
		long ans = Long.MIN_VALUE;
		for(int i=1; i<=M; i++) {
			int c = readInt(), f = readInt();
			ans = Math.max(ans, dp[c] - f);
		}
		System.out.println(ans);
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}