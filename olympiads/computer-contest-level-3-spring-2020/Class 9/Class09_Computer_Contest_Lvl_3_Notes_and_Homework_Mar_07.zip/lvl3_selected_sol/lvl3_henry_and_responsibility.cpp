#include <bits/stdc++.h>
using namespace std;
const int MM = 702;
int N, sum, a[MM], dp[MM*MM/2];
int main(){
    cin >> N;
    for(int i=1; i<=N; i++){
        cin >> a[i]; sum+=a[i];
    }
    int half = sum/2;  dp[0] = 1;
    for(int i=1; i<=N; i++){
        for(int j=half; j>=a[i]; j--)
            if(!dp[j]) dp[j] = dp[j-a[i]];
    }
    for(int i=half; i>=0; i--){
        if(dp[i]) { cout << sum - 2*i << "\n"; return 0; }
    }
}