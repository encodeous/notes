import java.util.*;
import java.io.*;
public class homework {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static PrintWriter pr = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
	static StringTokenizer st;
	public static void main(String[] args) throws IOException {
		char s[] = readLine().toCharArray(), t[] = readLine().toCharArray(); 
		int fs[] = new int[26], ft[] = new int[26];
		for(int i=0; i<s.length; i++) fs[s[i] - 'a']++;
		long hash[] = new long[t.length+1], p[] = new long[t.length+1], base = 131;
		p[0] = 1;
		for(int i=1; i<=t.length; i++) {
			hash[i] = hash[i-1]*base + t[i-1];
			p[i] = p[i-1]*base;
		}
		Set<Long> set = new HashSet<Long>();
		for(int i=1; i<Math.min(s.length, t.length); i++) ft[t[i-1]-'a']++;
		for(int i=s.length; i<=t.length; i++) {
			ft[t[i-1]-'a']++;  
			if(i>s.length) ft[t[i-s.length-1]-'a']--;
			if(!Arrays.equals(fs, ft)) continue;
			set.add(getSubstrHash(hash, p, i-s.length+1, i));
		}
		System.out.println(set.size());
	}
	static long getSubstrHash(long hash[], long p[], int l, int r) {
		return hash[r] - hash[l-1] * p[r-l+1];
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}