import java.util.*;
import java.io.*;
public class homework {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static PrintWriter pr = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
	static StringTokenizer st;
	public static void main(String[] args) throws IOException {
		int n = readInt(), f[] = new int[n+4], e[] = new int[n+4];
		for(int i=1; i<=n; i++) f[i] = readInt();
		for(int i=1; i<=n; i++) e[i] = readInt();
		int dp[] = new int[n+4];
		dp[1] = Math.max(f[1], e[1]); dp[2] = dp[1] + Math.max(f[2], e[2]);
		for(int i=3; i<=n; i++) {
			dp[i] = dp[i-1] + e[i];
			dp[i] = Math.max(dp[i], dp[i-2] + e[i-1] + Math.max(f[i], e[i]));
			dp[i] = Math.max(dp[i], dp[i-3] + e[i-2] + Math.max(f[i-1], e[i-1]) + Math.max(f[i], e[i]));
		}
		System.out.println(dp[n]);
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}