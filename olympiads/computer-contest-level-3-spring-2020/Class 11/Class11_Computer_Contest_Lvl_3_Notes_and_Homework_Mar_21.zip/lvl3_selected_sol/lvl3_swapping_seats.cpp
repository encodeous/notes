#include <bits/stdc++.h>
using namespace std;
const int MM = 1e6+3;
int n, na, nb, nc, a[MM], b[MM], c[MM], ans = 1e9; string s;
void check(int x[], int y[], int i){
    int nx = x[n], ny = y[n], swaps = nx - (x[i]-x[i-nx]) + ny - (y[i-nx]-y[i-nx-ny]);
    swaps -= min(y[i] - y[i-nx], x[i-nx]-x[i-nx-ny]);
    ans = min(ans, swaps);
}
int main(){
    cin >> s; n = s.size();
    for(int i=1; i<=n; i++){
        if(s[i-1] == 'A') a[i]=1;
        if(s[i-1] == 'B') b[i]=1;
        if(s[i-1] == 'C') c[i]=1;
        a[i]+=a[i-1]; b[i]+=b[i-1]; c[i]+=c[i-1];
    }
    na = a[n]; nb = b[n]; nc = c[n];
    for(int i=1; i<=n; i++){
        if(i >= na + nb) { check(a, b, i); check(b, a, i); }
        if(i >= na + nc) { check(a, c, i); check(c, a, i); }
        if(i >= nb + nc) { check(b, c, i); check(c, b, i); }
    }
    cout << ans << "\n";
}