#include <iostream>
#include <string>
#include <vector>
#include <cstdio>
#include <queue>
using namespace std;
vector<string> city;
queue<pair<int, int> > Q;
string str;
int n, m, cnt=0, trap[1001][1001];
void check_to_push(int y, int x, char c)
{
    if(y>=0&&y<n&&x>=0&&x<m&&(!trap[y][x])&&(city[y][x]==c)){
        trap[y][x]=cnt;
        Q.push(make_pair(y, x));
    }
}

int main()
{   //freopen("test.txt", "r", stdin);
    cin >> n >> m;
    for(int i=0; i<n; i++){
        cin >> str;
        city.push_back(str);
    }
    for(int i=0; i<n; i++)
        for(int j=0; j<m; j++){
            if(trap[i][j]>0) continue;
            trap[i][j]=++cnt;
            Q.push(make_pair(i, j));
            while(!Q.empty()){
                int row=Q.front().first, col=Q.front().second;
                Q.pop();
                check_to_push(row-1, col, 'S');
                check_to_push(row, col+1, 'W');
                check_to_push(row+1, col, 'N');
                check_to_push(row, col-1, 'E');
                if(city[row][col]=='S') row++;
                else if(city[row][col]=='N') row--;
                else if(city[row][col]=='E') col++;
                else col--;
                if(!trap[row][col]){
                    trap[row][col]=cnt;
                    Q.push(make_pair(row, col));
                }
            }
        }
    cout << cnt << endl;
}