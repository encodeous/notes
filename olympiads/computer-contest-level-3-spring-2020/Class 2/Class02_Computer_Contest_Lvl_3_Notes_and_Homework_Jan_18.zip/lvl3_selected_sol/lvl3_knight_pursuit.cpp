#include <bits/stdc++.h>
using namespace std;
typedef pair<int, int> pi;
int T, R, C, dis[101][101], pr, pc, kr, kc;
int d[8][2]={{-1, -2}, {1, -2}, {-2, -1}, {2, -1}, {-2, 1}, {2, 1}, {1, 2}, {-1, 2}};
int main(){
    cin >> T;
    for(int t=1; t<=T; t++){
        cin >> R >> C >> pr >> pc >> kr >> kc;
        memset(dis, -1, sizeof(dis));
        int stale=-1, winmove=0; bool win=false; queue<pi> q;
        dis[kr][kc] = 0;  q.push({kr, kc});
        while(!q.empty()){
            int r=q.front().first, c=q.front().second; q.pop();
            for(int k=0; k<8; k++){
                int nr = r + d[k][0], nc = c + d[k][1];
                if(nr>0 && nr<=R && nc>0 && nc<=C && dis[nr][nc]==-1){
                    dis[nr][nc] = dis[r][c]+1; q.push({nr, nc});
                }
            }
        }
        for(int i=pr; i<R && !win; i++){
            int t = i - pr;
            if(dis[i][pc]>=0 && dis[i][pc]<=t && (t-dis[i][pc])%2==0){
                win = true; winmove=t;
            }
            if(stale==-1 && dis[i+1][pc]>=0 && dis[i+1][pc]<=t+1 &&(t - dis[i+1][pc]) % 2 == 0){
                stale = t;
            }
        }
        if(win) printf("Win in %d knight move(s).\n", winmove);
        else if(stale != -1) printf("Stalemate in %d knight move(s).\n", stale);
        else printf("Loss in %d knight move(s).\n", R-pr-1);
    }
}