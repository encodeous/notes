import java.util.*;
import java.io.*;
import java.math.*;
public class homework {
    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    static StringTokenizer st;
    public static void main(String[] args) throws IOException{
    	int n = readInt(), dp[][] = new int[2*n + 1][2*n + 1];
    	for(int i=1; i<=n; i++) {
    		dp[i][i] = dp[n+i][n+i] = readInt() % 2;
    	}
    	for(int len=1; len<n; len++) {
    		for(int lft=1; lft+len<=2*n; lft++) {
    			int rit = lft + len;
    			dp[lft][rit] = Math.max(dp[lft][lft] - dp[lft+1][rit], dp[rit][rit] - dp[lft][rit-1]);
    		}
    	}
    	int ans = 0;
    	for(int i=1; i<=n; i++)
    		if(dp[i][i] - dp[i+1][i-1+n] > 0) ans++;
    	System.out.println(ans);
    }
    static String next () throws IOException {
        while (st == null || !st.hasMoreTokens())
            st = new StringTokenizer(br.readLine().trim());
        return st.nextToken();
    }
    static long readLong () throws IOException {
        return Long.parseLong(next());
    }
    static int readInt () throws IOException {
        return Integer.parseInt(next());
    }
    static double readDouble () throws IOException {
        return Double.parseDouble(next());
    }
    static char readCharacter () throws IOException {
        return next().charAt(0);
    }
    static String readLine () throws IOException {
        return br.readLine().trim();
    }
}