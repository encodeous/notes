import java.util.*;
import java.io.*;
import java.math.*;
public class homework {
    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    static StringTokenizer st;
    static int n, adj[][], dp[][];
    public static void main(String[] args) throws IOException{
    	n =  readInt(); adj = new int[n+1][n+1]; dp = new int[n+1][n+1];
    	for(int i=1; i<=n; i++)
    		for(int j=1; j<=n; j++)
    			adj[i][j] = readInt();
    	System.out.println(fun(1, 1));
    }
    static int fun(int lft, int rit) {
    	if(lft == n || rit == n) return 0;
    	if(dp[lft][rit] > 0) return dp[lft][rit];
    	int nxt = Math.max(lft, rit) + 1; // nxt lft ... rit  or lft .. rit nxt
    	dp[lft][rit] = Math.min(adj[nxt][lft] + fun(nxt, rit), adj[rit][nxt] + fun(lft, nxt));
    	return dp[lft][rit];
    }
    static String next () throws IOException {
        while (st == null || !st.hasMoreTokens())
            st = new StringTokenizer(br.readLine().trim());
        return st.nextToken();
    }
    static long readLong () throws IOException {
        return Long.parseLong(next());
    }
    static int readInt () throws IOException {
        return Integer.parseInt(next());
    }
    static double readDouble () throws IOException {
        return Double.parseDouble(next());
    }
    static char readCharacter () throws IOException {
        return next().charAt(0);
    }
    static String readLine () throws IOException {
        return br.readLine().trim();
    }
}