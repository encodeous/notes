import java.util.*;
import java.io.*;
import java.math.*;
public class homework {
    static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    static StringTokenizer st;
    static int n, h[], dp[];
    public static void main(String[] args) throws IOException{
    	for(int t=1; t<=5; t++) {
    		String ans = "";
    		for(int tt=1; tt<=3; tt++) {
    			n = readInt(); h = new int[n]; dp = new int[1<<n];
    			Arrays.fill(dp, -1);
    			for(int i=0; i<n; i++) h[i] = readInt();
    			if(fun((1<<n)-1)==1) ans += "B";
    			else ans += "A";
    		}
    		System.out.println(ans);
    	}
    }
    static int fun(int mask) {
    	if(dp[mask] != -1) return dp[mask];
    	if(isIncOrDec(mask)) return dp[mask] = 1; //lose;
    	int result = 0; 
    	for(int k=0; k<n; k++)
    		if((mask & 1<<k)!= 0) result |= fun(mask - (1<<k));
    	return dp[mask]= result==1? 0:1; //if result is lose, current is win
    }
    static boolean isIncOrDec(int mask) {
    	List<Integer> t = new ArrayList();
    	for(int k=0; k<n; k++)
    		if((mask & 1<<k) != 0) t.add(h[k]);
    	boolean inc = true, dec = true;
    	for(int k=1; k<t.size(); k++) {
    		if(t.get(k) > t.get(k-1)) dec = false;
    		if(t.get(k) < t.get(k-1)) inc = false;
    	}
    	return inc || dec;
    }
    static String next () throws IOException {
        while (st == null || !st.hasMoreTokens())
            st = new StringTokenizer(br.readLine().trim());
        return st.nextToken();
    }
    static long readLong () throws IOException {
        return Long.parseLong(next());
    }
    static int readInt () throws IOException {
        return Integer.parseInt(next());
    }
    static double readDouble () throws IOException {
        return Double.parseDouble(next());
    }
    static char readCharacter () throws IOException {
        return next().charAt(0);
    }
    static String readLine () throws IOException {
        return br.readLine().trim();
    }
}