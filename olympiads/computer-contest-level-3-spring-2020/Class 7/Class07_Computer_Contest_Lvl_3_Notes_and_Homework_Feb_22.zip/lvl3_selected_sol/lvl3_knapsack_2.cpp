#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int MM = 1e5+2;
int N, W, maxV=1e5; ll dp[MM];
int main(){
    cin >> N >> W;
    fill(dp, dp+MM, 1e9+2); dp[0] = 0;
    for(int i=1, w, v; i<=N; i++){
        cin >> w >> v;
        for(int j=maxV; j>=v; j--)
            dp[j] = min(dp[j], dp[j-v] + w);
    }
    for(int i=maxV; i>=0; i--){
        if(dp[i] <= W) { cout << i << endl;  return 0; }
    }
}