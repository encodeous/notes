import java.util.*;
public class test {
    public static void main(String [] args){
    	Scanner in = new Scanner(System.in);
    	int A = in.nextInt(), B = in.nextInt(), M = in.nextInt();
    	Integer loc[] = {0, 990, 1010, 1970, 2030, 2940, 3060, 3930, 4060, 4970, 5030, 5990, 6010, 7000};
    	List<Integer> pos = new ArrayList(Arrays.asList(loc));
    	for(int i=0; i<M; i++) pos.add(in.nextInt());
    	Collections.sort(pos);
    	long dp[] = new long [pos.size()];  dp[0] = 1;
    	for(int i=1; i<pos.size(); i++){
    		for(int j = 0; j<i; j++){
    			int dis = pos.get(i) - pos.get(j);
    			if(dis >= A && dis <= B) dp[i] += dp[j];
    		}
    	}
    	System.out.println(dp[pos.size()-1]);
    }
}