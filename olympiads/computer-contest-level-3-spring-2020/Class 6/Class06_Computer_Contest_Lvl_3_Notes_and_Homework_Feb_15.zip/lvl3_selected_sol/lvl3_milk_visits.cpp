#include <bits/stdc++.h>
using namespace std;
const int MM  = 1e5 + 5;
int N, M, p[MM]; char s[MM], ch, ans[MM];
int find_set(int d){ return d==p[d]? p[d]: p[d]=find_set(p[d]); }
int main(){
    //freopen("test.txt", "r", stdin);
    scanf("%d %d %s", &N, &M, s+1);
    for(int i=1; i<=N; i++) p[i] = i;
    for(int i=1, u, v; i<N; i++){
        scanf("%d %d", &u, &v);
        if(s[u] == s[v]){
            int fu = find_set(u), fv = find_set(v);
            if(fu != fv) p[fu] = fv;
        }
    }
    for(int i=1, u, v; i<=M; i++){
        scanf("%d %d %c", &u, &v, &ch);
        if(s[u] == ch || s[v] == ch || find_set(u) != find_set(v)) printf("1");
        else printf("0");
    }
}