#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
struct E{ int w, x, d;};
int N, L, tot, cnt, tt; vector<E> p; deque<int> lft, rit, wt; ll ans;
bool cmp(E a, E b){ return a.x < b.x;}
int main(){
    scanf("%d %d", &N, &L);
    for(int i=1, w, x, d; i<=N; i++){
        scanf("%d %d %d", &w, &x, &d);
        p.push_back(E{w, x, d}); tot += w;
    }
    sort(p.begin(), p.end(), cmp);
    for(int i=0; i<(int)p.size(); i++){
        if(p[i].d < 0) lft.push_back(p[i].x);
        else rit.push_back(p[i].x);
        wt.push_back(p[i].w);
    }
    while(cnt*2 < tot) {
        int tl = 1e9, tr = 1e9;
        if(!lft.empty()) tl = lft.front();
        if(!rit.empty()) tr = L - rit.back();
        if(tl < tr){
            cnt += wt.front(); tt = tl;
            if(!rit.empty()) ans += upper_bound(rit.begin(), rit.end(), lft.front()) - rit.begin();
            wt.pop_front(); lft.pop_front();
        }else {
            cnt += wt.back(); tt = tr;
            if(!lft.empty()){
                int pos = lower_bound(lft.begin(), lft.end(), rit.back()) - lft.begin();
                ans += ((int)lft.size() - pos);
            }
            wt.pop_back(); rit.pop_back();
        }
    }
    for(int tl: lft){
        ans += upper_bound(rit.begin(), rit.end(), tl) - lower_bound(rit.begin(), rit.end(), tl-2*tt);
    }
    cout << ans << endl;
}