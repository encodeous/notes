import java.util.*;
import java.io.*;
public class Test {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static PrintWriter pr = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
	static StringTokenizer st;
	public static void main(String[] args) throws IOException {
		int N = readInt(), K = readInt(), a[] = new int[N], mx = 0;
		for(int i=0; i<N; i++) { 
			a[i] = readInt(); mx = Math.max(mx, a[i]); 
		}
		int rem[] = new int[N], ans = 0;
		for(int x=1; x<=mx; x++) {
			int cnt = 0;
			for(int i=0; i<N; i++) cnt+=a[i]/x;
			if(cnt < K/2) break;
			if (cnt >= K) {
				ans = Math.max(ans, x*K/2);
			} else {
				for(int i=0; i<N; i++) rem[i] = a[i] % x;
				Arrays.sort(rem); 
				int tmp = (cnt - K/2) * x, rest = Math.min(K-cnt, N);
				for(int i=0; i<rest; i++) tmp += rem[N-i-1];
				ans = Math.max(ans, tmp);
			}
		}
		System.out.println(ans);
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}