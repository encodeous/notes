import java.util.*;
import java.io.*;
public class Test {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static PrintWriter pr = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
	static StringTokenizer st;
	static int N, M, minX[], maxX[], minY[], maxY[], p[];
	public static void main(String[] args) throws IOException {
		N = readInt(); M = readInt();
		minX = new int[N+1]; maxX = new int[N+1]; minY = new int[N+1]; maxY = new int[N+1];
		p = new int[N+1];
		for(int i=1; i<=N; i++) {
			int x = readInt(), y = readInt();
			p[i] = i; minX[i] = maxX[i] = x; minY[i] = maxY[i] = y;
		}
		for(int i=1; i<=M; i++) {
			int u = find_set(readInt()), v = find_set(readInt());
			if(u != v) {
				p[u] = v;
				maxX[v] = Math.max(maxX[v], maxX[u]);
				minX[v] = Math.min(minX[v], minX[u]);
				maxY[v] = Math.max(maxY[v], maxY[u]);
				minY[v] = Math.min(minY[v], minY[u]);
			}
		}
		int ans = Integer.MAX_VALUE;
		for(int i=1; i<=N; i++) {
			if(p[i]==i) ans = Math.min(ans, 2*(maxX[i]-minX[i]+maxY[i]-minY[i]));
		}
		System.out.println(ans);
	}
	static int find_set(int d) {
		if (d != p[d]) p[d] = find_set(p[d]);
		return p[d];
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}