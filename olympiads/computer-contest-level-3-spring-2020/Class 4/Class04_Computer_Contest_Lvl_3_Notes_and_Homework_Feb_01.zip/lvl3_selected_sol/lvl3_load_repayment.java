import java.util.*;
import java.io.*;
public class Test {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static PrintWriter pr = new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
	static StringTokenizer st;
	static long N, K, M;
	public static void main(String[] args) throws IOException {
		N = readLong(); K = readLong(); M = readLong();
		long lo = 1, hi = N, ans = 0;
		while(lo <= hi) {
			long mid = (lo + hi)/2;
			if(check(mid) >= N) { ans = mid; lo = mid + 1; }
			else hi = mid - 1;
		}
		System.out.println(ans);
	}
	static long check(long x) {
		long tot = 0, day = 0;
		while (day < K) {
			long y = (N-tot)/x;
			if (y <= M) return tot + (K-day)*M;
			long num_days_give_y = Math.min(K-day, (N-x*y-tot)/y + 1);
			tot += num_days_give_y * y; day += num_days_give_y;
		}
		return tot;
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}