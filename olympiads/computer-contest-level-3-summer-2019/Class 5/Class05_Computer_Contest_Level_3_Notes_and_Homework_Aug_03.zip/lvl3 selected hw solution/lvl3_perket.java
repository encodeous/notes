import java.util.*;
public class slot_machine {
	static int sour[], bit[], ans = Integer.MAX_VALUE;
    public static void main(String[] args){
    	Scanner in = new Scanner(System.in);
    	int n = in.nextInt(), a[] = new int[n];   sour = new int[n]; bit = new int[n];
    	for(int i=0; i<n; i++) {
    		a[i] = i; sour[i] = in.nextInt(); bit[i] = in.nextInt();
    	}
    	List<Integer> sol = new ArrayList();
    	fun(0, a, sol);   System.out.println(ans);
    }
    static void fun(int cur, int a[], List<Integer> sol) {
    	if( cur == a.length ) {
    		if(sol.isEmpty()) return ;
    		int totsour = 1, totbit = 0;
    		for(int item: sol) {
    			totsour *= sour[item]; totbit += bit[item];
    		}
    		ans =Math.min(ans, Math.abs(totsour - totbit)); return;
    	}
    	//not pick a[cur]
    	fun(cur+1, a, sol);
    	//pick up a[cur]
    	sol.add(a[cur]);
    	fun(cur+1, a, sol);
    	sol.remove(sol.size()-1);
    }
}