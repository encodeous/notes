import java.util.*;
public class homework {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int x = in.nextInt(); char digit[] = String.valueOf(x).toCharArray();
		Arrays.sort(digit);
		for(int i=x+1; ; i++) {
			char cmp[] = String.valueOf(i).toCharArray();
			if(cmp.length > digit.length) { System.out.println(0); break; }
			Arrays.sort(cmp);
			if(Arrays.equals(digit, cmp)) { System.out.println(i); break; }
		}
	}
}