import java.util.*;
import java.io.*;
public class Test {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static StringTokenizer st;
	public static void main(String[] args) throws IOException {
		int n = readInt(), q = readInt(), a[] = new int[n+2];
		int pmax[] = new int[n+2], pcnt[] = new int[n+2], smax[] = new int[n+2], scnt[] = new int[n+2];
		for(int i=1; i<=n; i++) {
			a[i] = readInt();
			pmax[i] = Math.max(pmax[i-1], a[i]);
			if(pmax[i-1] > a[i]) pcnt[i] = pcnt[i-1];
			else if(pmax[i-1] == a[i]) pcnt[i] = pcnt[i-1] + 1;
			else pcnt[i] = 1;
		}
		for(int i=n; i>=1; i--) {
			smax[i] = Math.max(smax[i+1], a[i]);
			if(smax[i+1] > a[i]) scnt[i] = scnt[i+1];
			else if(smax[i+1] == a[i]) scnt[i] = scnt[i+1] + 1;
			else scnt[i] = 1;
		}
		for(int i=1; i<=q; i++) {
			int x = readInt(), y = readInt();
			if(pmax[x-1] > smax[y+1]) System.out.println(pmax[x-1] + " " + pcnt[x-1]);
			else if(pmax[x-1] == smax[y+1]) System.out.println(pmax[x-1] + " " + (pcnt[x-1]+scnt[y+1]));
			else System.out.println(smax[y+1] + " " + scnt[y+1]);
		}
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}

 