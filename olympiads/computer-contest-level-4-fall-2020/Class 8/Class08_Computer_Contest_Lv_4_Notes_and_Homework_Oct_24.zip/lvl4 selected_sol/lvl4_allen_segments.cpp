#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int MM  = 1e5+2, LOG = 18;
struct Event { int l, r, v; };
int N, Q, node[MM], dep[MM], anc[LOG][MM]; vector<Event> vec, p;  vector<int> adj[MM];
bool cmp(Event x, Event y) { return x.l < y.l; }
void dfs(int u, int pa, int best){
    anc[0][u] = pa; node[u] = best;
    if(vec[u].v <= vec[node[best]].v) node[u] = u;
    for(int i=1; i<LOG; i++)
        if(anc[i-1][u] != -1) anc[i][u] = anc[i-1][anc[i-1][u]];
    for(int v: adj[u]){
        if(v == pa) continue;
        dep[v] = dep[u] + 1; dfs(v, u, node[u]);
    }
}
int LCA(int u, int v){
    if(dep[u] < dep[v]) swap(u, v);
    for(int i=LOG-1; i>=0; i--)
        if(anc[i][u] != -1 && dep[anc[i][u]] >= dep[v]) u = anc[i][u];
    if(u == v) return anc[0][u];
    for(int i=LOG-1; i>=0; i--)
        if(anc[i][u] != -1 && anc[i][v]!=-1 && anc[i][u] != anc[i][v])
            u = anc[i][u], v = anc[i][v];
    return anc[0][u];
}
int main(){
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    cin >> N;  vec.resize(N+1); memset(anc, -1, sizeof(anc));
    for(int i=1; i<=N; i++){
        cin >> vec[i].l >> vec[i].r >> vec[i].v;
        p.push_back(Event{vec[i].l, i, 0}); //insert left endpoint
        p.push_back(Event{vec[i].r, i, 1}); //insert right endpoint
    }
    sort(p.begin(), p.end(), cmp);
    stack<int> stk; stk.push(0);
    for(Event x: p){
        if(x.v == 0) { adj[stk.top()].push_back(x.r); stk.push(x.r); }
        else stk.pop();
    }
    vec[0].v = 1e9; dfs(0, -1, 0);
    cin >> Q;
    for(int i=1, u, v; i<=Q; i++){
        cin >> u >> v;  int rt = LCA(u, v);
        cout << (rt!=0? node[rt]:-1) << "\n";
    }
}