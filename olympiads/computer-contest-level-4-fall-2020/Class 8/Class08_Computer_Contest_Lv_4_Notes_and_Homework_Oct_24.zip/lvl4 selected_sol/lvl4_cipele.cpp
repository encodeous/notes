#include <bits/stdc++.h>
using namespace std;
int N, M, ans; vector<int> lft, rit;
bool check(int x){
    int cnt = 0;
    for(int i=0, j=0; i < N && j < M; ){
        if(abs(lft[i] - rit[j]) <= x){
            i++; j++; cnt++;
        }else if(lft[i] < rit[j]) {
            i++;
        }else if(lft[i] > rit[j]) {
            j++;
        }
    }
    return cnt == min(N, M);
}
int main(){
    scanf("%d %d", &N, &M);
    for(int i=0, x; i<N; i++){
        scanf("%d", &x); lft.push_back(x);
    }
    for(int i=0, x; i<M; i++){
        scanf("%d", &x); rit.push_back(x);
    }
    sort(lft.begin(), lft.end()); sort(rit.begin(), rit.end());
    int lo = 0, hi = 1e9;
    while(lo <= hi){
        int mid = (lo + hi)/2;
        if(check(mid)) { ans = mid; hi = mid-1; }
        else lo = mid + 1;
    }
    printf("%d\n", ans);
}