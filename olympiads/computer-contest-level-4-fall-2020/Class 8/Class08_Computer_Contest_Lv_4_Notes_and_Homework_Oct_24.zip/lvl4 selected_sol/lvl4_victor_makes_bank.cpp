#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int mod = 1e9+7;
struct matrix {
    vector<vector<ll>> d;
    matrix(){}
    matrix(int sz){ d.resize(sz, vector<ll>(sz, 0)); }
    void identity() {
        for(int i=0; i<d.size(); i++) d[i][i] = 1;
    }
};
matrix multi(matrix a, matrix b){
    int n = a.d.size();
    matrix ans(n);
    for(int i=0; i<n; i++)
        for(int k=0; k<n; k++)
            for(int j=0; j<n; j++)
                ans.d[i][j] = (ans.d[i][j] + a.d[i][k]*b.d[k][j])%mod;
    return ans;
}
matrix quick_pow(matrix a, ll exp){
    int n = a.d.size();
    matrix ans(n); ans.identity();
    while(exp > 0){
        if(exp % 2 != 0) ans = multi(ans, a);
        a = multi(a, a); exp /= 2;
    }
    return ans;
}
ll N, K, T, C, ans;
int main(){
    cin >> N >> K >> T >> C;
    matrix x(T+1);
    x.d[T][T] = 1;  x.d[0][T] = K;
    for(int i=1; i<=T; i++) x.d[i][i-1] = 1;
    x = quick_pow(x, N-1);
    ans = 2*C*x.d[T][T] % mod;
    for(int i=0; i<T; i++) ans = (ans + 1*C*x.d[i][T]%mod) %mod;
    cout << ans << endl;
}