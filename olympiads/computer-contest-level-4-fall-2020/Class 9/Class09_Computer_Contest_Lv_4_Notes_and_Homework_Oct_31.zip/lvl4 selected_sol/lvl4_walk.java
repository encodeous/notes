import java.util.*;
import java.io.*;
public class homework {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static StringTokenizer st;
	static int mod = (int)(1e9+7);
	public static void main(String[] args) throws IOException{
		int n = readInt(); long k = readLong(), adj[][] = new long[n][n];
		for(int i=0; i<n; i++)
			for(int j=0; j<n; j++)
				adj[i][j] = readLong();
		adj = quick_pow(adj, k);
		long ans = 0;
		for(int i=0; i<n; i++)
			for(int j=0; j<n; j++)
				ans = (ans + adj[i][j])%mod;
		System.out.println(ans);
	}
	static long [][] quick_pow(long a[][], long exp){
		if(exp == 1) return a;
		long [][] tmp = quick_pow(a, exp/2);
		tmp = multi(tmp, tmp);
		if(exp % 2 == 0) return tmp;
		return multi(tmp, a);
	}
	static long [][] multi(long a[][], long b[][]){
		long [][] ret = new long[a.length][b[0].length];
		for(int i=0; i<a.length; i++)
			for(int j=0; j<b[0].length; j++)
				for(int k=0; k<a[0].length; k++)
					ret[i][j] = (ret[i][j] + a[i][k]*b[k][j])%mod;
		return ret;
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}