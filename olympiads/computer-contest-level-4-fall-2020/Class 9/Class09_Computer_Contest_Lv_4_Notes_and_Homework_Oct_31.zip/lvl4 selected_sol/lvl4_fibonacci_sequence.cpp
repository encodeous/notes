#include <bits/stdc++.h>
using namespace std;
typedef unsigned long long ull;
typedef vector<vector<ull>> matrix;
const int mod = 1e9+7;
ull n; matrix a(2, vector<ull>(2)), id(2, vector<ull>(2));
matrix multi(matrix a, matrix b){
    matrix ans(a.size(), vector<ull>(b[0].size(), 0));
    for(int i=0; i<2; i++)
        for(int j=0; j<2; j++)
            for(int k=0; k<2; k++)
                ans[i][j] = (ans[i][j] + a[i][k]*b[k][j])%mod;
    return ans;
}
matrix quick_pow(matrix x, ull exp){
    if(exp == 0) return id;
    matrix tmp = quick_pow(x, exp/2);
    tmp = multi(tmp, tmp);
    if(exp % 2 == 0) return tmp;
    return multi(tmp, x);
}
int main(){
    cin >> n;
    a[0][1]=a[1][0]=a[1][1]=1;
    id[0][0] = id[1][1] = 1;
    a = quick_pow(a, n-1);
    cout << a[1][1] << endl;
}