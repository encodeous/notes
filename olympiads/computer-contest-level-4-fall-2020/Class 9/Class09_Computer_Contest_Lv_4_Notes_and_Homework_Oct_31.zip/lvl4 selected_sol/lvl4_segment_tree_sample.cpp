#include <bits/stdc++.h>
using namespace std;
const int MM = 1e5+5;
struct node {
    int l, r, mi;
}seg[3*MM];
int n, m, a[MM]; char op;
void build(int l, int r, int idx){
    seg[idx].l = l; seg[idx].r = r;
    if(l == r) {seg[idx].mi = a[l]; return; }
    int mid = (l + r)/2;
    build(l, mid, 2*idx); build(mid+1, r, 2*idx+1);
    seg[idx].mi = min(seg[2*idx].mi, seg[2*idx+1].mi);
}
void update(int pos, int val, int idx){
    if(seg[idx].l == seg[idx].r){
        seg[idx].mi = val; return;
    }
    int mid = (seg[idx].l + seg[idx].r)/2;
    if(pos <= mid) update(pos, val, 2*idx);
    else update(pos, val, 2*idx+1);
    seg[idx].mi = min(seg[2*idx].mi, seg[2*idx+1].mi);
}
int rmq(int l, int r, int idx){
    if(seg[idx].l == l && seg[idx].r == r) return seg[idx].mi;
    int mid = (seg[idx].l + seg[idx].r)/2;
    if(r <= mid) return rmq(l, r, 2*idx);
    else if(l > mid) return rmq(l, r, 2*idx+1);
    else return min(rmq(l, mid, 2*idx), rmq(mid+1, r, 2*idx+1));
}
int main(){
    cin >> n >> m;
    for(int i=1; i<=n; i++) cin >> a[i];
    build(1, n, 1);
    for(int i=1, x, y; i<=m; i++){
        cin >> op >> x >> y;
        if(op == 'M') update(x+1, y, 1);
        if(op == 'Q') cout << rmq(x+1, y+1, 1) << "\n";
    }
}