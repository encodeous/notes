#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int MM = 1502;
int H, V, y[MM], x[MM]; unordered_map<int, int> mp; ll ans;
int main(){
    cin >> H >> V;
    for(int i=1; i<=H; i++){
        cin >> y[i];
        for(int j=1; j<i; j++)
            mp[y[i]-y[j]]++;
    }
    for(int i=1; i<=V; i++){
        cin >> x[i];
        for(int j=1; j<i; j++)
            ans += mp[x[i]-x[j]];
    }
    cout << ans << endl;
}