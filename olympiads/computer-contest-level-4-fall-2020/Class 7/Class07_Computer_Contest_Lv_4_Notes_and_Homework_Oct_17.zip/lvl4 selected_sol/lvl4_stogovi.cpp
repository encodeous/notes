#include<bits/stdc++.h>
using namespace std;
const int MM = 3e5+5, LOG = 19;
int N, node[MM], pa[LOG][MM], dep[MM]; char op;
int lca(int x, int y){
    if(dep[x] < dep[y]) swap(x, y);
    for(int i=LOG-1; i>=0; i--)
        if(pa[i][x] !=-1 && dep[pa[i][x]] >= dep[y]) x = pa[i][x];
    if(x == y) return x;
    for(int i=LOG-1; i>=0; i--)
        if(pa[i][x]!=-1 && pa[i][y]!=-1 && pa[i][x] != pa[i][y])
            x = pa[i][x], y = pa[i][y];
    return pa[0][x];
}
int main(){
    scanf("%d", &N); memset(pa, -1, sizeof(pa));
    for(int i=1, v, w; i<=N; i++){
        scanf(" %c %d", &op, &v);
        if(op == 'a'){
            int p = node[v]; node[i] = i;
            dep[i] = dep[p] + 1; pa[0][i] = p;
            for(int j=1; j<LOG; j++)
                if(pa[j-1][i] != -1) pa[j][i] = pa[j-1][pa[j-1][i]];
        }else if(op == 'b'){
            int p = node[v];
            printf("%d\n", p);
            node[i] = pa[0][p];
        }else{
            scanf("%d", &w); node[i] = node[v];
            printf("%d\n", dep[lca(node[v], node[w])]);
        }
    }
}