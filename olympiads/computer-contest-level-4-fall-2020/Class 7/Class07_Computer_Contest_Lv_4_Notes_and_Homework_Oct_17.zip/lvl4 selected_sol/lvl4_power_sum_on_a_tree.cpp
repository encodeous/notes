#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int MM = 3e5 + 5, LOG=19, mod = 998244353;
int N, Q, dep[MM], anc[LOG][MM]; vector<int> adj[MM]; ll p[MM][51];
void dfs(int u, int pa){
    dep[u] = dep[pa] + 1; anc[0][u] = pa; p[u][0] = 1;
    for(int i=1; i<LOG; i++) anc[i][u] = anc[i-1][anc[i-1][u]];
    for(int i=1; i<=50; i++) p[u][i] = p[u][i-1]*(dep[u]-1) % mod;
    for(int i=1; i<=50; i++) p[u][i] = (p[pa][i] + p[u][i])%mod;
    for(int v: adj[u])
        if(v != pa) dfs(v, u);
}
int LCA(int u, int v){
    if(dep[u] < dep[v]) swap(u, v);
    for(int i=LOG-1; i>=0; i--)
        if(dep[anc[i][u]] >= dep[v]) u = anc[i][u];
    if(u == v) return u;
    for(int i=LOG-1; i>=0; i--)
        if(anc[i][u] != anc[i][v]) u = anc[i][u], v = anc[i][v];
    return anc[0][u];
}
int main(){
    cin >> N;
    for(int i=1, u, v; i<N; i++){
        cin >> u >> v;
        adj[u].push_back(v); adj[v].push_back(u);
    }
    dfs(1, 0);
    cin >> Q;
    for(int i=1, u, v, k; i<=Q; i++){
        cin >> u >> v >> k;  int rt = LCA(u, v);
        cout << ((p[u][k] + p[v][k] - p[rt][k] - p[anc[0][rt]][k])%mod + mod)%mod << "\n";
    }
}