#include <bits/stdc++.h>
using namespace std;
int W, T, D, a[10]; unordered_set<int> cur;
int main(){
    cin >> W >> D;
    for(int i=0; i<D; i++) {
        cin >> a[i]; cur.insert(a[i]);
    }
    for(int i=1; i<=W; i++){
        unordered_set<int> nxt;
        for(int x: cur){
            for(int i=0; i<D; i++){
                nxt.insert(x + a[i]); nxt.insert(x*a[i]);
            }
        }
        cur = nxt;
    }
    cin >> T;
    for(int i=1, x; i<=T; i++){
        cin >> x;
        cout << (cur.count(x)? "Y": "N") << "\n";
    }
}