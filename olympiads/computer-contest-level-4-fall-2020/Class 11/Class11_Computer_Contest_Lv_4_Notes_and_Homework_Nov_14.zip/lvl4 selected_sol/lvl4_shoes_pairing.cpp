#include <bits/stdc++.h>
using namespace std;
typedef pair<int, int> pi;
typedef long long ll;
const int MM = 2e5+5;
int N, rit[MM], suf[MM], ans[MM]; pi lft[MM];
int main(){
    ios::sync_with_stdio(0); cin.tie(0);
    cin >> N;
    for(int i=0, x; i<=N; i++){
        cin >> x;  lft[i] = {x, i};
    }
    for(int i=0; i<N; i++) cin >> rit[i];
    sort(lft, lft+N+1); sort(rit, rit+N);
    for(int i=N-1; i>=0; i--)
        suf[i] = max(suf[i+1], lft[i+1].first - rit[i]);
    int pre = 0;
    for(int i=0; i<=N; i++){
        ans[lft[i].second] = max(pre, suf[i]);
        pre = max(pre, lft[i].first - rit[i]);
    }
    for(int i=0; i<=N; i++)
        cout << ans[i] << " ";
}