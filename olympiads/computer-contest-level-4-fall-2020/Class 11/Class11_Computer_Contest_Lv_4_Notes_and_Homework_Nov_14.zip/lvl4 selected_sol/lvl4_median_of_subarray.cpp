#include <bits/stdc++.h>
using namespace std;
typedef pair<int, int> pi;
typedef long long ll;
const int MM = 1e5+2;
int N, x, a[MM], bit[2*MM]; ll ans;
void upd(int pos, int val){
    for(int i=pos+MM; i<2*MM; i+=i&-i) bit[i] += val;
}
int qry(int pos){
    int sum = 0;
    for(int i=pos+MM; i>0; i-=i&-i) sum += bit[i];
    return sum;
}
int main(){
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    cin >> N >> x; upd(0, 1);
    for(int i=1; i<=N; i++){
        cin >> a[i];  a[i] = a[i]>=x? 1:-1;
        a[i] += a[i-1];
        ans += qry(a[i]); upd(a[i], 1);
    }
    cout << ans << endl;
}