#include <bits/stdc++.h>
using namespace std;
typedef pair<int, int> pi;
typedef long long ll;
const int MM = 2e5+5, MV = 1e6+2, LOG=18;
int N, Q, a[MM], last[2*MV], lft[MM], rit[MM], mx[LOG][MM];
int rmq(int l, int r){
    int k = log2(r-l+1);
    return max(mx[k][l], mx[k][r-(1<<k)+1]);
}
int main(){
    ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    cin >> N >> Q;
    for(int i=1; i<=N; i++){
        cin >> a[i];
        lft[i] = min(lft[i-1]+1, i - last[a[i]+MV]); last[a[i]+MV] = i;
    }
    fill(last, last+2*MV, N+1);
    for(int i=N; i>=1; i--){
        mx[0][i] = rit[i] = min(rit[i+1]+1, last[a[i]+MV] - i); last[a[i]+MV] = i;
    }
    for(int i=1; i<LOG; i++)
        for(int j=1; j+(1<<i)-1<=N; j++)
            mx[i][j]=max(mx[i-1][j], mx[i-1][j+(1<<(i-1))]);
    for(int i=1, l, r; i<=Q; i++){
        cin >> l >> r;
        if(lft[r] >= r-l+1) cout << r-l+1 << "\n";
        else cout << max(lft[r], rmq(l, r-lft[r])) << "\n";
    }
}