import java.util.*;
import java.io.*;
public class homework {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static StringTokenizer st;
	public static void main(String[] args) throws IOException{
		int n = readInt(), m = readInt(), t = readInt(), cost[] = new int[n+1], free = 0;
		for(int i=1; i<=n; i++) cost[i] = readInt();
		double val[] = new double[n+1];
		for(int i=1; i<=m; i++) {
			int num = readInt();
			if(num == 0) free ++;
			for(int j=1; j<=num; j++) {
				int x = readInt(); val[x] += 1.0/num;
			}
		}
		double dp[] = new double[t+1];
		for(int i=1; i<=n; i++)
			for(int j=t; j>=cost[i]; j--)
				dp[j] = Math.max(dp[j], dp[j-cost[i]] + val[i]);
		System.out.printf("%.2f\n", dp[t] + free);
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}