#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll x, y; vector<ll> v, ans; bool adj[8][8]; int vis[8], pre[8], st, ed; queue<int> q;
bool isPrime(ll x){
    if(x < 2) return false;
    ll up = sqrt(x);
    for(ll i=2; i<=up; i++)
        if(x % i == 0) return false;
    return true;
}
int main(){
    cin >> x >> y;
    if(isPrime(abs(x-y))) { cout << 2 << "\n" << x << " " << y << "\n"; return 0; }
    for(int i=-2; i<=2; i+=2){
        if(i==0) {st = v.size(); ed = st+1; }
        if(isPrime(x+i)) v.push_back(x+i);
        if(isPrime(y+i)) v.push_back(y+i);
    }
    v.push_back(2);
    for(int i=0; i<v.size(); i++){
        for(int j=i+1; j<v.size(); j++)
            if(isPrime(abs(v[i] - v[j]))) adj[i][j] = adj[j][i]=true;
    }
    memset(pre, -1, sizeof(pre)); q.push(st); vis[st] = 1;
    while(!q.empty()){
        int u = q.front(); q.pop();
        for(int i=0; i<v.size(); i++){
            if(adj[u][i] && !vis[i]) { q.push(i); vis[i] = 1; pre[i] = u; }
        }
    }
    if(!vis[ed]) { cout << "-1\n"; return 0;}
    for(int i=ed; i!=-1; i=pre[i]) ans.push_back(v[i]);
    cout << ans.size() << "\n";
    for(int i=(int)ans.size()-1; i>=0; i--) cout << ans[i] << " ";
}