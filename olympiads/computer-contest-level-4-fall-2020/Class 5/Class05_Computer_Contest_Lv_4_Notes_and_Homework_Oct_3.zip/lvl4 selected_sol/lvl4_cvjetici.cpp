#include <cstdio>
using namespace std;
#define MAXN 100000
#define lowbit(x) ((x)&(-x))
int bit[100001],cont[100001];
inline void Read(int &x){
    char c=0, r=0, n=0; x=0;
    while(1){
        c=getchar();
        if((c=='-')&&!r) n=1;
        else if(c>='0'&&c<='9') x=x*10+c-'0', r=1;
        else if(r) break;
    }
    if(n) x=-x;
}
void add(int idx, int u){
    for(int x=idx; x<=MAXN; x+=lowbit(x))
        bit[x] += u;
}
int sum(int u){
    int ans=0;
    for(int x=u; x>0; x-=lowbit(x))
        ans+=bit[x];
    return ans;
}

int main(){
    //freopen("test.txt", "r", stdin);
    int N, l, r;
    Read(N);
    for(int i = 0; i < N; ++i){
        Read(l), Read(r);
        int s1 = sum(l), s2= sum(r);
        printf("%d\n",s1 + s2 - cont[l] - cont[r]);
        cont[l] = s1; cont[r] = s2;
        add(l+1,1);  add(r,-1);
    }
    return 0;
}