#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<int, int> pi;
const int MM = 2e5+2;
ll N, M, K, X, psa[MM]; pi freq[MM]; int ans[MM], idx;
int main(){
    cin >> N >> M >> K >> X;
    for(int i=1; i<=N; i++){
        cin >> freq[i].first; freq[i].second = i;
    }
    sort(freq+1, freq+N+1);
    for(int i=1; i<=N; i++)
        psa[i] = psa[i-1] + freq[i].first;
    int lft = 0, rit = N;
    while(lft <= N && psa[lft] < K) lft++;
    while(rit >= 0  && psa[N] - psa[rit] < K) rit--;
    if(X > lft || X < N - rit) { cout << -1 << endl; return 0;}
    for(int i=X; i<=N; i++){
        if(psa[i] - psa[i-X] >= K){
            for(int j=i-X+1; j<=i; j++)
                ans[freq[j].second] = ++idx;
            for(int j=1; j<=N; j++){
                if(ans[j] == 0) ans[j] = ++idx;
                cout << ans[j] << " ";
            }
            cout << endl; return 0;
        }
    }
    cout << -1 << endl;
}