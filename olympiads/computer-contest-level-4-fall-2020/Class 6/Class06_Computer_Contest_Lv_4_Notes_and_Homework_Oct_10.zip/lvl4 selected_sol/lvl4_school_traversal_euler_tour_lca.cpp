#include <bits/stdc++.h>
using namespace std;
typedef pair<int, int> pii;
int N, Q, dep[6002], p[6002]; vector<pii> adj[6002], anc[16]; long long dis[6002];
void dfs(int u, int pa, long long d){
    dis[u] = d; dep[u] = dep[pa]+1;  p[u] = anc[0].size();
    anc[0].push_back({dep[u], u});
    for(auto e: adj[u]){
        if(e.first == pa) continue;
        dfs(e.first, u, d+e.second);
        anc[0].push_back({dep[u], u});
    }
}
int lca(int u, int v){
    if(u == v) return u;
    if(p[u] > p[v]) swap(u, v);
    int k = (int)log2(p[v]-p[u]+1); pii t = min(anc[k][p[u]], anc[k][p[v]-(1<<k)+1]);
    return t.second;
}
int main(){
    scanf("%d", &N);
    for(int i=1, u, v, w; i<N; i++){
        scanf("%d %d %d", &u, &v, &w);
        adj[u].push_back({v, w}); adj[v].push_back({u, w});
    }
    dfs(0, 0, 0);
    for(int i=1; i<16; i++)
        for(int j=0; j+(1<<(i-1))<anc[i-1].size(); j++)
            anc[i].push_back(min(anc[i-1][j], anc[i-1][j+(1<<(i-1))]));
    scanf("%d", &Q);
    for(int i=0, u, v; i<Q; i++){
        scanf("%d %d", &u, &v);
        printf("%lld\n", dis[u] + dis[v] - 2*dis[lca(u, v)]);
    }
}