#include <bits/stdc++.h>
using namespace std;
typedef pair<int, int> pi;
typedef long long ll;
const int MM = 6003, LOG = 13;
int N, Q, lca[LOG][MM], dep[MM]; ll dis[MM]; vector<pi> adj[MM];
void dfs(int u, int pa){
    for(pi e: adj[u]){
        int v = e.first, w = e.second;
        if(v != pa) {
            dep[v] = dep[u] + 1; dis[v] = dis[u] + w;
            lca[0][v] = u;  dfs(v, u);
        }
    }
}
void build_lca(){
    for(int i=1; i<LOG; i++)
        for(int j=0; j<N; j++)
            if(lca[i-1][j] != -1) lca[i][j] = lca[i-1][lca[i-1][j]];
}
int getlca(int u, int v){
    if(dep[u] < dep[v]) swap(u, v);
    for(int i=LOG-1; i>=0; i--)
        if(lca[i][u] != -1 && dep[lca[i][u]] >= dep[v]) u = lca[i][u];
    if(u == v) return u;
    for(int i=LOG-1; i>=0; i--)
        if(lca[i][u] != -1 && lca[i][v]!=-1 && lca[i][u] != lca[i][v]) u = lca[i][u], v= lca[i][v];
    return lca[0][u];
}
int main(){
    scanf("%d", &N);  memset(lca, -1, sizeof(lca));
    for(int i=1, u, v, w; i<N; i++){
        scanf("%d %d %d", &u, &v, &w);
        adj[u].push_back({v, w}); adj[v].push_back({u, w});
    }
    dfs(0, -1);  build_lca(); scanf("%d", &Q);
    for(int i=1, u, v; i<=Q; i++){
        scanf("%d %d", &u, &v); int rt = getlca(u, v);
        printf("%lld\n", dis[u] + dis[v] - 2*dis[rt]);
    }

}