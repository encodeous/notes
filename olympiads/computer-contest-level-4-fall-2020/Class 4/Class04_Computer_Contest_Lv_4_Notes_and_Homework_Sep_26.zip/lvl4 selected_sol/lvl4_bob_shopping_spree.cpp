#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int MM = 1005;
int N, M, K, cost[MM], val[MM]; ll dp[MM];
int main(){
    cin >> N >> M >> K;
    for(int i=1; i<=N; i++){
        cin >> cost[i] >> val[i];
        for(int j=cost[i]; j<=K; j++)
            dp[j] = max(dp[j], dp[j-cost[i]] + val[i]);
    }
    for(int i=1, q, t, d, a; i<=M; i++){
        cin >> q >> t >> d >> a;
        for(int k=1; k<=a; k=k*2){
            ll w = k*d, v = (ll)k*q*val[t];
            for(int j=K; j>=w; j--)
                dp[j] = max(dp[j], dp[j-w] + v);
            a -= k;
        }
        ll w = a*d, v = (ll)a*q*val[t];
        for(int j=K; j>=w; j--)
            dp[j] = max(dp[j], dp[j-w] + v);
    }
    cout << dp[K] << endl;
}