import java.util.*;
import java.io.*;
public class homework {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static StringTokenizer st;
	public static void main(String[] args) throws IOException{
		int n = readInt(), h[] = new int[n+1], a[] = new int[n+1];
		long bit[] = new long[n+1], ans = 0;
		for(int i=1; i<=n; i++) {
			h[i] = readInt();
		}
		for(int i=1; i<=n; i++) {
			a[i] = readInt();
			long max = query(h[i], bit);
			update(h[i], max+a[i], bit);
			ans = Math.max(ans, max+a[i]);
		}
		System.out.println(ans);
	}
	static long query(int pos, long bit[]) {
		long max = 0;
		for(int i=pos; i>0; i-=i&-i)
			max = Math.max(bit[i], max);
		return max;
	}
	static void update(int pos, long val, long bit[]) {
		for(int i=pos; i<bit.length; i+=i&-i)
			bit[i] = Math.max(bit[i], val);
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}