#include <bits/stdc++.h>
using namespace std;
typedef pair<int, int> pi;
const int MM = 4003;
int H, W, ans=0, d[4][2]={{-1,0},{1,0},{0,-1},{0, 1}}; bool vis[MM][MM]; char g[MM][MM]; queue<pi> q[2];
void bfs(){
    while(!q[0].empty()){
        int r = q[0].front().first, c = q[0].front().second; q[0].pop();
        for(int k=0; k<4; k++){
            int nr = r + d[k][0], nc = c + d[k][1];
            if(nr < 1 || nr > H || nc < 1 || nc > W || vis[nr][nc] || g[nr][nc]=='.') continue;
            if(g[nr][nc] == g[r][c]){
                q[0].push({nr, nc}); vis[nr][nc]=true;
            }else{
                q[1].push({nr, nc}); vis[nr][nc]=true;
            }
        }
    }
}
int main(){
    cin >> H >> W;
    for(int i=1; i<=H; i++)
        for(int j=1; j<=W; j++)
            cin >> g[i][j];
    q[0].push({1, 1}); vis[1][1]=true;
    while(true){
        ans++;  bfs();
        if(q[1].empty()) break;
        swap(q[0], q[1]);
    }
    cout << ans << endl;
}