#include <bits/stdc++.h>
using namespace std;
int N, a[100002], lp, rp, len, bit[100002]; unordered_map<int, int> mp;
void update(int pos, int val){
    for(int i=pos; i<=N; i+= i&-i)
        bit[i] += val;
}
int sum(int pos){
    int ans = 0;
    for(int i=pos; i>0; i-=i&-i)
        ans += bit[i];
    return ans;
}
int main(){
    //freopen("test.txt", "r", stdin);
    scanf("%d", &N);
    for(int i=1, x; i<=N; i++){
        scanf("%d", &x); mp[x]=i;
    }
    for(int i=1, x; i<=N; i++){
        scanf("%d", &x); a[i] = mp[x];
    }
    lp=rp=len=1;
    for(int i=2, last=1; i<=N; i++){
        if(a[i] < a[i-1]) last = i;
        if(i - last + 1 > len) { len = i-last+1; lp=last; rp=i;}
    }
    printf("%d\n", N-len);
    for(int i=1, j=0; i<=N; i++){
        bit[i]++;  j = i + (i & -i);
        if(j<=N) bit[j] += bit[i];
    }
    for(int i=rp+1; i<=N; i++){
        int t = sum(a[i]); update(a[i], -1);
        printf("B %d\n", t);
    }
    for(int i=lp-1, cnt=0; i>=1; i--){
        int t = sum(a[i]) + cnt; cnt++;  update(a[i], -1);
        printf("F %d\n", t);
    }
}