#include <bits/stdc++.h>
using namespace std;
const int MM = 30;
int N, Q; char g[MM][MM]; bool vis[30][30]; string s;
int d[8][2] = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}, {-1, -1}, {-1, 1}, {1, -1}, {1, 1}};
bool fun(int r, int c, string &s, int pos){
    if(s.length() == pos) return true;;
    vis[r][c] = 1; bool flag=false;
    for(int k=0; k<8; k++){
        int nr = r+d[k][0], nc=c+d[k][1];
        if(nr > 0 && nr <=N && nc > 0 && nc <= N && g[nr][nc]==s[pos] && !vis[nr][nc])
            flag |= fun(nr, nc, s, pos+1);
    }
    return flag;
}
int main(){
    //freopen("test.txt", "r", stdin);
    cin >> N >> Q;
    for(int i=1; i<=N; i++)
        for(int j=1; j<=N; j++)
            cin >> g[i][j];
    for(int k=1; k<=Q; k++){
        cin >> s;
        bool flag = false;
        for(int i=1; !flag && i<=N; i++){
            for(int j=1; !flag && j<=N; j++){
                if(g[i][j] != s[0]) continue;
                memset(vis, 0, sizeof(vis)); string t = "";
                flag = fun(i, j, s, 1);
                if(flag) goto nxt;
            }
        }
nxt:;
        if(flag) cout << "good puzzle!\n";
        else cout << "bad puzzle!\n";
    }
}