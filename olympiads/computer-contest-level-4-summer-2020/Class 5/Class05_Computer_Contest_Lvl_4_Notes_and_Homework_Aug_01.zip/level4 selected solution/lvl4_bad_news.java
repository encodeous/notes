import java.util.*;
import java.io.*;
public class homework {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static StringTokenizer st;
	static char g[][];
	public static void main(String[] args) throws IOException{
		int n = readInt(), q = readInt(); g = new char[n][n];
		for(int i=0; i<n; i++)
			for(int j=0; j<n; j++)
				g[i][j] = next().charAt(0);
		for(int t=1; t<=q; t++) {
			char s[] = readLine().toCharArray(); 
			boolean found = false;
			for(int i=0; i<n && !found; i++) {
				for(int j=0; j<n && !found; j++) {
					if(g[i][j] == s[0]) {
						boolean vis[][] = new boolean[n][n];
						found = fun(i, j, s, 1, vis);
					}
				}
			}
			if(found) System.out.println("good puzzle!");
			else  System.out.println("bad puzzle!");
		}
	}
	static boolean fun(int r, int c, char []s, int idx, boolean vis[][]) {
		if(idx == s.length) return true;
		vis[r][c] = true;  int n = vis.length;
		for(int dr = -1; dr<=1; dr++){
			for(int dc=-1; dc<=1; dc++) {
				int nr = r + dr, nc = c + dc;
				if(nr >= 0 && nr < n && nc >=0 && nc < n && !vis[nr][nc] && g[nr][nc] == s[idx]) {
					if(fun(nr, nc, s, idx+1, vis)) return true;
				}
			}
		}
		return false;
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}