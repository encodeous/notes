#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int MM = 1e5+5;
int N, M, K, dis[26][26], psa[MM][26], dp[MM], best[MM][26]; string s;
int main(){
    cin >> N >> M >> K >> s;
    for(int i=0; i<M; i++)
        for(int j=0; j<M; j++)
            cin >> dis[i][j];
    //floyd algorithm
    for(int k=0; k<M; k++)
        for(int i=0; i<M; i++)
            for(int j=0; j<M; j++)
                dis[i][j] = min(dis[i][j], dis[i][k] + dis[k][j]);
    for(int i=1; i<=N; i++)
        for(int j=0; j<M; j++)
            psa[i][j] = psa[i-1][j] + dis[s[i-1]-'a'][j];
    memset(dp, 0x3f, sizeof(dp)); dp[0] = 0;
    for(int i=K; i<=N; i++){
        for(int p=0; p<M; p++){
            dp[i] = min(dp[i], best[i-K][p] + psa[i][p]);
        }
        for(int p=0; p<M; p++){
            best[i][p] = min(best[i-1][p], dp[i] - psa[i][p]);
        }
    }
    cout << dp[N] << "\n";
}