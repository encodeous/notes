#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int MM = 5002, MV = 1e6+2;
int N, Q, a[MM], cnt[2*MV]; ll psa[MM][MM];
int main(){
    scanf("%d %d", &N, &Q);
    for(int i=1; i<=N; i++){
        scanf("%d", &a[i]);
    }
    for(int i=1; i<=N; i++){
        for(int k=i+1; k<=N; k++){
            int val = -a[i]-a[k]+MV;
            if(val >= 0 && val < 2*MV) psa[i][k] = cnt[val];
            cnt[a[k]+MV]++;
        }
        for(int k=i+1; k<=N; k++) cnt[a[k]+MV]--;
    }
    for(int i=1; i<=N; i++)
        for(int j=1; j<=N; j++)
            psa[i][j] += psa[i-1][j] + psa[i][j-1] - psa[i-1][j-1];
    for(int i=1, x, y; i<=Q; i++){
        scanf("%d %d", &x, &y);
        printf("%lld\n", psa[y][y] - psa[x-1][y] - psa[y][x-1] + psa[x-1][x-1]);
    }
}