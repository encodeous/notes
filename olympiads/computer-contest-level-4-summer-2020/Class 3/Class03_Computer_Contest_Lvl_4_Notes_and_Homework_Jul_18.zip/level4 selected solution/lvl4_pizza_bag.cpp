#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<ll, int> pli;
int N, K, v[200002]; deque< pli > Q; ll ans, psum;
int main(){
    cin >> N >> K;
    for(int i=0; i<N; i++){
        cin >> v[i];
        v[i+N] = v[i];
    }
    Q.push_back({0LL,-1});
    for(int i=0; i<N+K; i++){
        psum += v[i];
        while(!Q.empty() && i-Q.front().second > K)
            Q.pop_front();
        ans = max(ans, psum-Q.front().first);
        while(!Q.empty() && psum <= Q.back().first)
            Q.pop_back();
        Q.push_back({psum, i});
    }
    cout << ans << endl;
}