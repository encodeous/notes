import java.util.*;
import java.io.*;
public class homework {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static StringTokenizer st;
	public static void main(String[] args) throws IOException {
		int n = readInt(), k = readInt();
		boolean chair[] = new boolean[n+1];
		int student[] = new int[n+1];
		for(int i=0; i<k; i++){
			chair[readInt()] = true;
		}
		for(int i=1; i<=k+1; i++) {
			student[readInt()] = i;
		}
		Stack<Integer> stk = new Stack();
		for(int j=0; j<2; j++) {
			for(int i=1; i<=n; i++) {
				if(student[i] != 0) {
					stk.push(student[i]); student[i] = 0;
				}
				if(chair[i] && ! stk.isEmpty()) {
					chair[i] = false; stk.pop();
				}
			}
		}
		System.out.println(stk.pop());
	}
	static String next() throws IOException {
		while (st == null || !st.hasMoreTokens()) 
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong() throws IOException {
		return Long.parseLong(next());
	}
	static int readInt() throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble() throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter() throws IOException {
		return next().charAt(0);
	}
	static String readLine() throws IOException {
		return br.readLine().trim();
	}
}