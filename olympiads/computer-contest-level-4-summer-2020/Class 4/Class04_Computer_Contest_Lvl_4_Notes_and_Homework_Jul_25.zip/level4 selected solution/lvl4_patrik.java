import java.util.*;
import java.io.*;
public class homework {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static StringTokenizer st;
	public static void main(String[] args) throws IOException {
		int n = readInt(); long ans = 0;
		Stack<Integer> h = new Stack(), freq = new Stack();
		for(int i=1; i<=n; i++) {
			int cur = readInt();
			while(!h.isEmpty() && cur > h.peek()) {
				ans += freq.pop(); h.pop();
			}
			if(h.isEmpty()) {
				h.push(cur); freq.push(1);
			}else {
				if(cur == h.peek()) {
					ans += freq.peek(); 
					if(h.size()>=2) ans++;
					freq.push(freq.pop() + 1);
				}else {
					ans ++; 
					h.push(cur); freq.push(1);
				}
			}
		}
		System.out.println(ans);
	}
	static String next() throws IOException {
		while (st == null || !st.hasMoreTokens()) 
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong() throws IOException {
		return Long.parseLong(next());
	}
	static int readInt() throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble() throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter() throws IOException {
		return next().charAt(0);
	}
	static String readLine() throws IOException {
		return br.readLine().trim();
	}
}