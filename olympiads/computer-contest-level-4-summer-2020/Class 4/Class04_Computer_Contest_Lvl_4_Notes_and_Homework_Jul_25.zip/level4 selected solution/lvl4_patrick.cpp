#include <bits/stdc++.h>
using namespace std;
const int MM = 5e5+5;
int N, h[MM], cnt[MM], top = -1; long long ans = 0;
int main(){
    scanf("%d", &N);
    for(int i=1, x=0; i<=N; i++){
        scanf("%d", &x);
        while( top>=0 && h[top] < x ){
            ans += cnt[top]; top--;
        }
        if( top < 0 ){
            top++; h[top] = x; cnt[top] = 1;
        }else{
            if( h[top] == x ){
                ans += cnt[top];
                if(top >= 1) ans++;
                cnt[top]++;
            }else{
                ans ++; top++;
                h[top] = x; cnt[top] = 1;
            }
        }
    }
    printf("%lld\n", ans);
}