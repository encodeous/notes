import java.util.*;
import java.io.*;
public class homework {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static StringTokenizer st;
	public static void main(String[] args) throws IOException {
		int C = readInt(), R = readInt(), area = readInt(), psa[][]=new int[R+1][C+1];
		for(int i=1; i<=R; i++) {
			for(int j=1; j<=C; j++) {
				psa[i][j] = readInt();
				psa[i][j] += psa[i-1][j] + psa[i][j-1] - psa[i-1][j-1];
			}
		}
		int ans = 0;
		for(int r1=1; r1<=R; r1++) {
			for(int c1=1; c1<=C; c1++) {
				for(int w=1; w<=Math.min(area, R-r1+1); w++) {
					int r2 = r1 + w - 1, len = area/w, c2 = Math.min(c1 + len - 1, C);
					ans = Math.max(ans, psa[r2][c2] - psa[r2][c1-1] - psa[r1-1][c2] + psa[r1-1][c1-1]);
				}
			}
		}
		System.out.println(ans);
	}
	static String next() throws IOException {
		while (st == null || !st.hasMoreTokens()) 
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong() throws IOException {
		return Long.parseLong(next());
	}
	static int readInt() throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble() throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter() throws IOException {
		return next().charAt(0);
	}
	static String readLine() throws IOException {
		return br.readLine().trim();
	}
}