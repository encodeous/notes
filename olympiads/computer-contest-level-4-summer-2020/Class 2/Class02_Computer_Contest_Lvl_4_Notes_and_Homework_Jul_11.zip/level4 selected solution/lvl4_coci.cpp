#include <bits/stdc++.h>
using namespace std;
const int MM=5e5+5, up = 651;
int N, a[MM], b[MM], psa[652][652];
int main(){
    scanf("%d", &N);
    for(int i=1; i<=N; i++){
        scanf("%d %d", &a[i], &b[i]);
        a[i]++; b[i]++; psa[a[i]][b[i]]++;
    }
    for(int i=1; i<=up; i++)
        for(int j=1; j<=up; j++)
            psa[i][j] += psa[i-1][j] + psa[i][j-1] - psa[i-1][j-1];
    for(int i=1; i<=N; i++){
        int x = a[i], y = b[i];
        //sum from (x+1, y+1) to (650, 650)
        int best = psa[up][up] - psa[x][up] - psa[up][y] + psa[x][y];
        //sum from (0, 0) to (x-1, y-1)
        int worst = psa[x-1][y-1];
        if(x == up) worst += psa[1][y] - psa[1][y-1];
        if(y == up) worst += psa[x][1] - psa[x-1][1];
        printf("%d %d\n", best+1, N - worst);
    }
}