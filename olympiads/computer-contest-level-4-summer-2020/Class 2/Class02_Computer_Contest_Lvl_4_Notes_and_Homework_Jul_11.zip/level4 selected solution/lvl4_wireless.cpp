#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <algorithm>
using namespace std;
int places[1004][30004],m,n,k,r,b,x,y,d,cnt;
int main(){
    //freopen("test.txt", "r", stdin);
    scanf("%d %d %d",&m,&n,&k);
    while(k--){
        scanf("%d%d%d%d",&x, &y, &r, &b);
        for(int j=max(1, x-r); j<=min(n, x+r); j++){
            d=(int)sqrt(r*r-(j-x)*(j-x));
            places[j][max(1,y-d)]+=b;
            places[j][min(y+d+1, m+1)]-=b;
        }
    }
    cnt=b=0;
    for(int j=1;j<=n;++j)
        for(int i=1, k=0;i<=m;++i){
            k+=places[j][i];
            if(k>=b){
                if(k==b) ++cnt;
                else    {cnt=1; b=k;}
            }
        }
    printf("%d\n%d\n",b,cnt);
    return 0;
}
