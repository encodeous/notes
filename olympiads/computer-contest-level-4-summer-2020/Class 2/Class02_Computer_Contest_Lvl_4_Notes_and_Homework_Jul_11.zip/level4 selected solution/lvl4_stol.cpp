#include <bits/stdc++.h>
#define INF 0x3f3f3f3f
#define ll long long
#define ull unsigned long long
#define pii pair<int, int>
#define pll pair<ll, ll>
#define pdd pair<double, double>
#define endl "\n"
#define pb push_back
using namespace std;
int r, c;
int psa[401][401];
bool isValid(int r1, int r2, int c1, int c2){
    int sum = psa[r2][c2] - psa[r1-1][c2] - psa[r2][c1-1] + psa[r1-1][c1-1];
    return sum==0; //Look at that so big brain wow 100% not gonna backfire
}

int main(){
    ios_base::sync_with_stdio(false); cin.tie(NULL);
    cin >> r >> c;
    for(int i = 1; i <= r; i++){
        for(int j = 1; j <= c; j++){
            char ch; cin >> ch;
            psa[i][j] = psa[i][j-1] + psa[i-1][j] - psa[i-1][j-1]+ (ch == 'X');
        }
    }
    int ans = 0;
    for(int r1 = 1; r1 <= r; r1++){
        for(int r2 = r1; r2 <= r; r2++){
            int c1 = 1;
            for(int c2 = 1; c2 <= c; c2++){
                if(!isValid(r1, r2, c1, c2)){
                    c1 = c2 + 1;
                } else {
                    ans = max(ans, 2*(r2 - r1 + 1) + 2*(c2 - c1 + 1));
                }
            }
        }
    }
    cout << ans-1 << endl;
    return 0;
}