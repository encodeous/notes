import java.util.*;
import java.io.*;
public class homework {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static StringTokenizer st;
	public static void main(String[] args) throws IOException {
		int n = readInt(), t = readInt();
		long [] da = new long[t+2], db = new long[t+2], dc = new long[t+2];
		for(int i=1; i<=n; i++) {
			int x = readInt(), y = readInt(), a = readInt(), b = readInt(), c = readInt();
			long va = a, vb = b - 2L*a*x, vc = 1L*a*x*x - 1L*b*x +c;
			da[x] += va; db[x] += vb; dc[x] += vc;
			da[y+1] -= va; db[y+1] -= vb; dc[y+1] -= vc;
		}
		for(int i=1; i<=t; i++) {
			da[i] += da[i-1]; db[i] += db[i-1]; dc[i] += dc[i-1];
			System.out.print(da[i]*i*i + db[i]*i + dc[i] + " ");
		}
		System.out.println();
	}
	static String next() throws IOException {
		while (st == null || !st.hasMoreTokens()) 
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong() throws IOException {
		return Long.parseLong(next());
	}

	static int readInt() throws IOException {
		return Integer.parseInt(next());
	}

	static double readDouble() throws IOException {
		return Double.parseDouble(next());
	}

	static char readCharacter() throws IOException {
		return next().charAt(0);
	}

	static String readLine() throws IOException {
		return br.readLine().trim();
	}
}