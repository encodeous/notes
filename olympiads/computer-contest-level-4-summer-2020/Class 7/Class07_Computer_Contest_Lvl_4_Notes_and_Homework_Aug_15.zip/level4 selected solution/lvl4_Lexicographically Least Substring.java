import java.util.*;
import java.io.*;
public class homework {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static StringTokenizer st;
	static long [] hash, p;
	public static void main(String[] args) throws IOException{
		String s = " " + readLine();  int n = s.length(), seed = 131, k = readInt();
		hash = new long[n]; p = new long[n]; char min = 'z';
		p[0] = 1;
		for(int i=1; i<n; i++) {
			hash[i] = hash[i-1] * seed + s.charAt(i);
			p[i] = p[i-1] * seed;
			if(i+k<=n && s.charAt(i) < min) min = s.charAt(i);
		}
		int ans = 1;
		for(int i=2; i+k <= n; i++) {
			if(s.charAt(i) != min) continue;
			int lo = 0, hi = k-1, first = hi;
			while(lo <= hi) {
				int mid = (lo + hi) / 2;
				if(getSubHash(ans, ans+mid) == getSubHash(i, i+mid)) {
					lo = mid + 1;
				}else {
					first = mid; hi = mid - 1;
				}
			}
			if(s.charAt(ans+first) > s.charAt(i+first)) ans = i;
		}
		System.out.println(s.substring(ans, ans+k));
	}
	static long getSubHash(int l, int r) { return hash[r] - hash[l-1]*p[r-l+1]; }
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}