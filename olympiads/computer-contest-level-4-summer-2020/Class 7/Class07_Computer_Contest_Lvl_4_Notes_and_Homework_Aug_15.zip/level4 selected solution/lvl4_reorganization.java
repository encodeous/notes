import java.util.*;
import java.io.*;
public class homework {
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	static StringTokenizer st;
	public static void main(String[] args) throws IOException{
		int n = readInt(); TreeMap<Integer, Integer> map = new TreeMap();
		int first = readInt(); 
		map.put(first, 0);
		for(int i=2; i<=n; i++) {
			int rk = readInt();
			Integer key = map.floorKey(rk);
			if(key == null) {
				System.out.println("NO"); return;
			}
			map.put(rk, 0);
			map.put(key, map.get(key) + 1); 
			if(map.get(key) == 2) map.remove(key);
		}
		System.out.println("YES");
	}
	static String next () throws IOException {
		while (st == null || !st.hasMoreTokens())
			st = new StringTokenizer(br.readLine().trim());
		return st.nextToken();
	}
	static long readLong () throws IOException {
		return Long.parseLong(next());
	}
	static int readInt () throws IOException {
		return Integer.parseInt(next());
	}
	static double readDouble () throws IOException {
		return Double.parseDouble(next());
	}
	static char readCharacter () throws IOException {
		return next().charAt(0);
	}
	static String readLine () throws IOException {
		return br.readLine().trim();
	}
}