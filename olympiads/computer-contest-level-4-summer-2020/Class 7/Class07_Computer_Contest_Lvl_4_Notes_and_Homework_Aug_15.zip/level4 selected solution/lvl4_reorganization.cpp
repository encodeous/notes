#include <bits/stdc++.h>
using namespace std;
int n, rk; map<int, int> mp;
int main(){
    cin >> n >> rk;
    mp[rk] = 0;
    for(int i=2; i<=n; i++){
        cin >> rk;
        auto it = mp.lower_bound(rk);
        if(it == mp.begin()) { cout << "NO\n"; return 0; }
        it--; it->second ++;
        if(it->second == 2) mp.erase(it);
        mp[rk] = 0;
    }
    cout << "YES\n";
}