#include <bits/stdc++.h>
using namespace std;
const int MM = 500002;
int n, a[MM], psa[MM], mx = INT_MIN, lft=-1, rit=-1; vector<int> cnt[2*MM];
int main(){
    //freopen("test.txt", "r", stdin);
    scanf("%d", &n);
    for(int i=1; i<=n; i++){
        scanf("%d", &a[i]);
        psa[i] = psa[i-1] + (a[i] == i);
        int t = i + a[i]; cnt[t].push_back(abs(a[i] - i));
    }
    for(int i=1; i<=2*n; i++){
        if(cnt[i].empty()) continue;
        sort(cnt[i].begin(), cnt[i].end());
        for(int k=0; k<cnt[i].size(); k++){
            int ll = (i - cnt[i][k])/2, rr = (i + cnt[i][k])/2;
            int tmp = k+1 - psa[rr] + psa[ll-1];
            if(tmp > mx){ mx = tmp; lft = ll; rit = rr; }
        }
    }
    printf("%d %d\n", a[lft], a[rit]);
}