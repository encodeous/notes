#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int N, base=131, ans; unordered_map<ll, int> mp; string s;
int main(){
    cin >> N;
    for(int t=1; t<=N; t++){
        cin >> s;
        ll pre=0, suf=0, pw=1; int best=0;
        for(int i=0; i<s.size(); i++){
            pre = pre*base + s[i];
            suf = suf + s[(int)s.size()-i-1]*pw;  pw *= base;
            if(pre == suf) best = max(best, mp[pre]);
        }
        ans = max(ans, best+1); mp[pre] = best+1;
    }
    cout << ans << "\n";
}